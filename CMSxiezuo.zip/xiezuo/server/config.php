<?php
// 数据库配置：请根据实际环境修改
return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'dbname' => 'cms',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
    // 初始化令牌：仅用于首次部署在 Web 下触发初始化（seed），使用后请置空
    'init_token' => 'changeme',
];