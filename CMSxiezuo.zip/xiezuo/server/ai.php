<?php
require_once __DIR__ . '/db.php';

function list_ai_models(): array {
  $pdo = getPDO();
  return $pdo->query('SELECT * FROM ai_models ORDER BY id DESC')->fetchAll();
}

function create_ai_model(string $name, string $provider, string $api_base, string $api_key, string $model, ?array $settings, string $status = 'active'): int {
  $pdo = getPDO();
  $stmt = $pdo->prepare('INSERT INTO ai_models (name, provider, api_base, api_key, model, settings, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
  $stmt->execute([$name, $provider, $api_base, $api_key, $model, $settings ? json_encode($settings) : null, $status]);
  return (int)$pdo->lastInsertId();
}

function update_ai_model(int $id, array $fields): void {
  $pdo = getPDO();
  $columns = [];
  $values = [];
  foreach ($fields as $k => $v) { $columns[] = "$k = ?"; $values[] = $k === 'settings' && is_array($v) ? json_encode($v) : $v; }
  $values[] = $id;
  $sql = 'UPDATE ai_models SET '.implode(', ', $columns).' WHERE id = ?';
  $stmt = $pdo->prepare($sql);
  $stmt->execute($values);
}

function delete_ai_model(int $id): void {
  $pdo = getPDO();
  $pdo->prepare('DELETE FROM ai_models WHERE id=?')->execute([$id]);
}

function log_generation(?int $user_id, ?int $model_id, string $type, string $prompt, ?string $preview, ?int $tokens_used, string $status = 'success'): int {
  $pdo = getPDO();
  $stmt = $pdo->prepare('INSERT INTO ai_generation_logs (user_id, model_id, type, prompt, preview, tokens_used, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
  $stmt->execute([$user_id, $model_id, $type, $prompt, $preview, $tokens_used, $status]);
  return (int)$pdo->lastInsertId();
}

function list_generation_logs(int $limit = 50): array {
  $pdo = getPDO();
  $stmt = $pdo->prepare('SELECT l.*, u.username AS user_name, m.name AS model_name, m.model AS model_label FROM ai_generation_logs l LEFT JOIN users u ON l.user_id = u.id LEFT JOIN ai_models m ON l.model_id = m.id ORDER BY l.id DESC LIMIT ?');
  $stmt->bindValue(1, $limit, PDO::PARAM_INT);
  $stmt->execute();
  return $stmt->fetchAll();
}

function delete_generation_logs(array $ids): int {
  $ids = array_values(array_filter(array_map('intval', $ids), fn($x) => $x > 0));
  if (empty($ids)) { return 0; }
  $pdo = getPDO();
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $stmt = $pdo->prepare('DELETE FROM ai_generation_logs WHERE id IN ('.$placeholders.')');
  $stmt->execute($ids);
  return $stmt->rowCount();
}

function test_one_api_connectivity(int $modelId): array {
  $pdo = getPDO();
  $m = $pdo->prepare('SELECT * FROM ai_models WHERE id=?');
  $m->execute([$modelId]);
  $row = $m->fetch();
  if (!$row) { throw new RuntimeException('model_not_found'); }
  $url = build_api_url($row['api_base'], '/v1/models');
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer '.$row['api_key'], 'Content-Type: application/json'],
    CURLOPT_TIMEOUT => 10,
  ]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($err) { return ['ok' => false, 'error' => $err]; }
  return ['ok' => ($code >= 200 && $code < 300), 'status' => $code, 'body' => $body];
}

// --- Helper: fetch model by id ---
function get_ai_model(int $id): ?array {
  $pdo = getPDO();
  $stmt = $pdo->prepare('SELECT * FROM ai_models WHERE id=?');
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  return $row ?: null;
}

// --- Generic One-API request wrapper ---
function one_api_request(array $modelRow, string $endpoint, array $payload, bool $expectsBinary = false, int $timeout = 60): array {
  $url = build_api_url($modelRow['api_base'], $endpoint);
  $ch = curl_init($url);
  $headers = ['Authorization: Bearer '.$modelRow['api_key']];
  if (!$expectsBinary) { 
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Accept: application/json';
  }
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_TIMEOUT => $timeout,
  ]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($err) { return ['ok' => false, 'status' => $code, 'error' => $err, 'url' => $url]; }
  if ($expectsBinary) {
    $b64 = base64_encode($body ?: '');
    return ['ok' => ($code >= 200 && $code < 300), 'status' => $code, 'binary_b64' => $b64, 'url' => $url];
  }
  $json = null;
  if ($body !== false) {
    $json = json_decode($body, true);
  }
  return ['ok' => ($code >= 200 && $code < 300), 'status' => $code, 'json' => $json, 'raw' => $body, 'url' => $url];
}

// --- Image generation via One-API (OpenAI style) ---
function generate_image(int $modelId, string $prompt, string $size = '512x512'): array {
  $m = get_ai_model($modelId);
  if (!$m) { return ['ok' => false, 'error' => 'model_not_found']; }

  // 1) 优先尝试文档提供的 Chat(生成图片) 接口：/v1/chat/completions
  $chatPayload = [
    'model' => $m['model'],
    'stream' => false,
    'messages' => [
      ['role' => 'user', 'content' => $prompt]
    ]
  ];
  $chatRes = one_api_request($m, '/v1/chat/completions', $chatPayload, false, 90);
  if (!empty($chatRes['ok']) && !empty($chatRes['json']['choices'][0]['message'])) {
    $message = $chatRes['json']['choices'][0]['message'];
    // a) 直接字符串内容中包含图片 URL 或 dataURL
    $content = is_array($message['content'] ?? null) ? null : ($message['content'] ?? null);
    if (is_string($content) && $content !== '') {
      // 检测 dataURL(base64)
      if (preg_match('/^data:image\/(png|jpg|jpeg|webp);base64,/i', $content)) {
        return ['ok' => true, 'preview' => $content, 'usage' => $chatRes['json']['usage'] ?? null];
      }
      // 尝试从文本中提取 URL
      if (preg_match('/https?:\/\/[^\s"\'<>]+/i', $content, $mchs)) {
        return ['ok' => true, 'preview' => $mchs[0], 'usage' => $chatRes['json']['usage'] ?? null];
      }
      // 如果返回的是可解析的 JSON 字符串
      $asJson = json_decode($content, true);
      if (is_array($asJson)) {
        if (!empty($asJson['image_url'])) { return ['ok' => true, 'preview' => $asJson['image_url'], 'usage' => $chatRes['json']['usage'] ?? null]; }
        if (!empty($asJson['b64_json'])) { return ['ok' => true, 'preview' => 'data:image/png;base64,'.$asJson['b64_json'], 'usage' => $chatRes['json']['usage'] ?? null]; }
      }
    }
    // b) 非字符串内容或扩展字段（一些代理可能返回自定义结构）
    if (!empty($message['images'][0]['b64_json'])) {
      return ['ok' => true, 'preview' => 'data:image/png;base64,'.$message['images'][0]['b64_json'], 'usage' => $chatRes['json']['usage'] ?? null];
    }
    if (!empty($message['images'][0]['url'])) {
      return ['ok' => true, 'preview' => $message['images'][0]['url'], 'usage' => $chatRes['json']['usage'] ?? null];
    }
  }

  // 若 Chat 接口未返回可用图片，回退到标准图片生成端点（OpenAI风格）
  $payload = [
    'model' => $m['model'],
    'prompt' => $prompt,
    'size' => $size,
    'response_format' => 'b64_json'
  ];
  $endpoints = ['/v1/images/generations', '/images/generations', '/v1/images', '/images'];
  $res = ['ok' => false];
  foreach ($endpoints as $ep) {
    $try = one_api_request($m, $ep, $payload, false, 90);
    if (!empty($try['ok'])) { $res = $try; break; } else { $res = $try; }
  }
  if (!empty($res['json']['data'][0]['b64_json'])) {
    $imgB64 = $res['json']['data'][0]['b64_json'];
    return ['ok' => true, 'preview' => 'data:image/png;base64,'.$imgB64, 'usage' => $res['json']['usage'] ?? null];
  }
  if (!empty($res['json']['data'][0]['url'])) {
    return ['ok' => true, 'preview' => $res['json']['data'][0]['url'], 'usage' => $res['json']['usage'] ?? null];
  }
  // 如果两种方式都失败，返回更详尽的错误信息以便定位
  $errMsg = $res['json']['error']['message'] ?? ($chatRes['json']['error']['message'] ?? 'image_generation_failed');
  $status = $res['status'] ?? ($chatRes['status'] ?? null);
  $url = $res['url'] ?? ($chatRes['url'] ?? null);
  return ['ok' => false, 'error' => $errMsg, 'status' => $status, 'url' => $url];
}

// --- Audio TTS via One-API ---
function generate_audio_tts(int $modelId, string $text, string $voice = 'alloy', string $format = 'mp3'): array {
  $m = get_ai_model($modelId);
  if (!$m) { return ['ok' => false, 'error' => 'model_not_found']; }
  $payload = [
    'model' => $m['model'],
    'input' => $text,
    'voice' => $voice,
    'format' => $format
  ];
  $res = one_api_request($m, '/v1/audio/speech', $payload, true, 120);
  if ($res['ok'] && !empty($res['binary_b64'])) {
    $mime = $format === 'wav' ? 'audio/wav' : ($format === 'aac' ? 'audio/aac' : 'audio/mpeg');
    return ['ok' => true, 'preview' => 'data:'.$mime.';base64,'.$res['binary_b64']];
  }
  // Some providers return JSON with url
  if (!$res['ok'] && !empty($res['raw'])) {
    $json = json_decode($res['raw'], true);
    if (!empty($json['url'])) { return ['ok' => true, 'preview' => $json['url']]; }
  }
  return ['ok' => false, 'error' => $res['error'] ?? 'audio_generation_failed', 'status' => $res['status'] ?? null];
}

// --- Video generation (best-effort) ---
function generate_video(int $modelId, string $prompt, int $duration = 5): array {
  $m = get_ai_model($modelId);
  if (!$m) { return ['ok' => false, 'error' => 'model_not_found']; }
  $payload = [
    'model' => $m['model'],
    'prompt' => $prompt,
    'duration' => max(1, $duration)
  ];
  // Try common endpoints used by proxies
  $res = one_api_request($m, '/v1/videos', $payload, true, 180);
  if ($res['ok'] && !empty($res['binary_b64'])) {
    return ['ok' => true, 'preview' => 'data:video/mp4;base64,'.$res['binary_b64']];
  }
  // Fallback to JSON
  if (!$res['ok']) {
    $res2 = one_api_request($m, '/v1/video/generations', $payload, false, 180);
    if (!empty($res2['json']['data'][0]['url'])) { return ['ok' => true, 'preview' => $res2['json']['data'][0]['url']]; }
  }
  return ['ok' => false, 'error' => ($res['error'] ?? 'video_endpoint_not_available'), 'status' => $res['status'] ?? null];
}
// Build full URL while avoiding double /v1 prefix issues
function build_api_url(string $apiBase, string $endpoint): string {
  $base = rtrim($apiBase, '/');
  $path = $endpoint;
  // ensure endpoint starts with '/'
  if ($path === '' || $path[0] !== '/') { $path = '/'.$path; }
  // avoid double '/v1'
  $hasV1InBase = (substr($base, -3) === '/v1');
  $startsWithV1 = (substr($path, 0, 4) === '/v1/');
  if ($hasV1InBase && $startsWithV1) {
    $path = substr($path, 3); // remove leading '/v1'
  } elseif (!$hasV1InBase && !$startsWithV1) {
    // if base doesn't include v1 and endpoint also doesn't, add it
    $path = '/v1'.$path;
  }
  return $base.$path;
}