<?php
require_once __DIR__ . '/db.php';

function articles_count(?string $q = null): int {
    $pdo = getPDO();
    if ($q) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM articles WHERE title LIKE ?');
        $stmt->execute(['%' . $q . '%']);
        return (int)$stmt->fetchColumn();
    }
    return (int)$pdo->query('SELECT COUNT(*) FROM articles')->fetchColumn();
}

function list_articles(int $page = 1, int $perPage = 20, ?string $q = null): array {
    $pdo = getPDO();
    $offset = max(0, ($page - 1) * $perPage);
    $params = [];
    $where = '';
    if ($q) {
        $where = 'WHERE a.title LIKE :q';
        $params[':q'] = '%' . $q . '%';
    }
    $sql = "SELECT a.id, a.title, a.status, a.created_at, c.name AS category
            FROM articles a
            LEFT JOIN categories c ON a.category_id = c.id
            $where
            ORDER BY a.created_at DESC
            LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function list_categories(): array {
    $pdo = getPDO();
    return $pdo->query('SELECT id, name, slug, created_at FROM categories ORDER BY name ASC')->fetchAll();
}

function create_category(string $name, ?string $slug = null): int {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO categories (name, slug) VALUES (?, ?)');
    $stmt->execute([$name, $slug]);
    return (int)$pdo->lastInsertId();
}

function get_category(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, name, slug, created_at FROM categories WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function update_category(int $id, string $name, ?string $slug = null): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE categories SET name = ?, slug = ? WHERE id = ?');
    $stmt->execute([$name, $slug, $id]);
}

function delete_category(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
    $stmt->execute([$id]);
}

function get_article(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT a.*, c.name AS category FROM articles a LEFT JOIN categories c ON a.category_id = c.id WHERE a.id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function create_article(string $title, string $content, ?int $categoryId, int $authorId, string $status = 'draft'): int {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO articles (title, content, category_id, author_id, status) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$title, $content, $categoryId, $authorId, $status]);
    return (int)$pdo->lastInsertId();
}

function update_article(int $id, string $title, string $content, ?int $categoryId, string $status): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE articles SET title=?, content=?, category_id=?, status=? WHERE id=?');
    $stmt->execute([$title, $content, $categoryId, $status, $id]);
}

function delete_article(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM articles WHERE id=?');
    $stmt->execute([$id]);
}

// Comments management
function comments_count(?string $q = null, ?string $status = null): int {
    $pdo = getPDO();
    $where = [];
    $params = [];
    if ($q) { $where[] = '(author LIKE :q OR body LIKE :q)'; $params[':q'] = '%' . $q . '%'; }
    if ($status) { $where[] = 'status = :status'; $params[':status'] = $status; }
    $sql = 'SELECT COUNT(*) FROM comments' . (empty($where) ? '' : (' WHERE ' . implode(' AND ', $where)));
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
    $stmt->execute();
    return (int)$stmt->fetchColumn();
}

function list_comments(int $page = 1, int $perPage = 20, ?string $q = null, ?string $status = null): array {
    $pdo = getPDO();
    $offset = max(0, ($page - 1) * $perPage);
    $where = [];
    $params = [];
    if ($q) { $where[] = '(c.author LIKE :q OR c.body LIKE :q)'; $params[':q'] = '%' . $q . '%'; }
    if ($status) { $where[] = 'c.status = :status'; $params[':status'] = $status; }
    $sql = 'SELECT c.id, c.author, c.body, c.status, c.created_at, a.title AS article_title
            FROM comments c JOIN articles a ON c.article_id = a.id '
            . (empty($where) ? '' : ('WHERE ' . implode(' AND ', $where))) .
            ' ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset';
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function get_comment(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT c.*, a.title AS article_title FROM comments c JOIN articles a ON c.article_id = a.id WHERE c.id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function update_comment_status(int $id, string $status): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE comments SET status = ? WHERE id = ?');
    $stmt->execute([$status, $id]);
}

function bulk_update_comments_status(array $ids, string $status): void {
    if (empty($ids)) { return; }
    $pdo = getPDO();
    $in = implode(',', array_fill(0, count($ids), '?'));
    $params = array_map('intval', $ids);
    array_unshift($params, $status);
    $stmt = $pdo->prepare("UPDATE comments SET status = ? WHERE id IN ($in)");
    $stmt->execute($params);
}

function delete_comment(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM comments WHERE id = ?');
    $stmt->execute([$id]);
}

// Tags management
function list_tags(): array {
    $pdo = getPDO();
    return $pdo->query('SELECT id, name, created_at FROM tags ORDER BY name ASC')->fetchAll();
}

function get_tag(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, name, created_at FROM tags WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function create_tag(string $name): int {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO tags (name) VALUES (?)');
    $stmt->execute([$name]);
    return (int)$pdo->lastInsertId();
}

function update_tag(int $id, string $name): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE tags SET name = ? WHERE id = ?');
    $stmt->execute([$name, $id]);
}

function delete_tag(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM tags WHERE id = ?');
    $stmt->execute([$id]);
}

// --- Article metadata (format etc.) ---
function get_article_meta(int $articleId, string $key): ?string {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT meta_value FROM article_meta WHERE article_id=? AND meta_key=?');
    $stmt->execute([$articleId, $key]);
    $val = $stmt->fetchColumn();
    return $val !== false ? (string)$val : null;
}

function set_article_meta(int $articleId, string $key, ?string $value): void {
    $pdo = getPDO();
    if ($value === null || $value === '') {
        $del = $pdo->prepare('DELETE FROM article_meta WHERE article_id=? AND meta_key=?');
        $del->execute([$articleId, $key]);
        return;
    }
    $stmt = $pdo->prepare('INSERT INTO article_meta (article_id, meta_key, meta_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value)');
    $stmt->execute([$articleId, $key, $value]);
}

function get_article_format(int $articleId): string {
    $fmt = get_article_meta($articleId, 'format');
    return in_array($fmt, ['markdown','html'], true) ? $fmt : 'markdown';
}

// --- Safe Markdown rendering and basic HTML sanitize ---
function sanitize_html_basic(string $html): string {
    // Remove script/style tags
    $html = preg_replace('#<\s*(script|style)[^>]*>.*?<\s*/\s*\1\s*>#is', '', $html);
    // Remove on* event handlers and javascript: urls
    $html = preg_replace('/on[a-z]+\s*=\s*"[^"]*"/i', '', $html);
    $html = preg_replace('/on[a-z]+\s*=\s*\'[^\']*\'/i', '', $html);
    $html = preg_replace('/href\s*=\s*"\s*javascript:[^"]*"/i', 'href="#"', $html);
    $html = preg_replace("/href\s*=\s*\'\s*javascript:[^\']*\'/i", "href='#'", $html);
    return $html;
}

function render_markdown_safe(string $md): string {
    $text = str_replace(["\r\n","\r"], "\n", $md);
    $esc = htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    // Code fences ```
    $esc = preg_replace_callback('/```(.*?)\n([\s\S]*?)\n```/m', function($m){
        $lang = htmlspecialchars(trim($m[1]), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $code = htmlspecialchars($m[2], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        return '<pre class="code"><code data-lang="'.$lang.'">'.$code.'</code></pre>';
    }, $esc);

    // Headings # ...
    for ($i=6; $i>=1; $i--) {
        $pattern = '/^'.str_repeat('#',$i).'\s+(.+)$/m';
        $esc = preg_replace($pattern, '<h'.$i.'>$1</h'.$i.'>', $esc);
    }

    // Bold **text** and Italic *text*
    $esc = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $esc);
    $esc = preg_replace('/\*(.+?)\*/s', '<em>$1</em>', $esc);

    // Inline code `code`
    $esc = preg_replace('/`([^`]+)`/', '<code>$1</code>', $esc);

    // Links [text](url)
    $esc = preg_replace_callback('/\[([^\]]+)\]\(([^\)]+)\)/', function($m){
        $text = htmlspecialchars($m[1], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $url = htmlspecialchars($m[2], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        if (!preg_match('/^(https?:)?\/\//', $url)) { $url = '#'; }
        return '<a href="'.$url.'">'.$text.'</a>';
    }, $esc);

    // Lists - item
    $esc = preg_replace_callback('/^(?:-\s+.+\n?)+/m', function($m){
        $lines = preg_split('/\n/', trim($m[0]));
        $items = '';
        foreach ($lines as $line) {
            $items .= '<li>'.preg_replace('/^-\s+/', '', $line).'</li>';
        }
        return '<ul>'.$items.'</ul>';
    }, $esc);

    // Paragraphs: wrap loose lines
    $lines = preg_split('/\n\n+/', trim($esc));
    foreach ($lines as &$blk) {
        if (!preg_match('/^\s*<\/(h\d|ul|pre)/', $blk) && !preg_match('/^\s*<(h\d|ul|pre)/', $blk)) {
            $blk = '<p>'.$blk.'</p>';
        }
    }
    return implode("\n", $lines);
}
function get_article_tags(int $articleId): array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT t.id, t.name FROM article_tags at JOIN tags t ON at.tag_id = t.id WHERE at.article_id = ? ORDER BY t.name ASC');
    $stmt->execute([$articleId]);
    return $stmt->fetchAll();
}

function set_article_tags(int $articleId, array $tagIds): void {
    $pdo = getPDO();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('DELETE FROM article_tags WHERE article_id = ?')->execute([$articleId]);
        if (!empty($tagIds)) {
            $stmt = $pdo->prepare('INSERT INTO article_tags (article_id, tag_id) VALUES (?, ?)');
            foreach ($tagIds as $tid) {
                $stmt->execute([$articleId, (int)$tid]);
            }
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}