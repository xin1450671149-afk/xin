<?php
require_once __DIR__ . '/db.php';

function ensure_recharge_table_exists(PDO $pdo): void {
  try {
    $pdo->query('SELECT 1 FROM recharge_orders LIMIT 1');
  } catch (PDOException $e) {
    // 表不存在（42S02），执行 schema 以创建
    if ($e->getCode() === '42S02' || strpos($e->getMessage(), 'Base table or view not found') !== false) {
      runSqlFile($pdo, __DIR__ . '/../db/schema.sql');
    } else {
      throw $e;
    }
  }
}

function create_recharge_order(int $user_id, float $amount, string $gateway = 'alipay'): array {
  $pdo = getPDO();
  $out_trade_no = 'RC' . date('YmdHis') . rand(1000,9999);
  ensure_recharge_table_exists($pdo);
  $stmt = $pdo->prepare('INSERT INTO recharge_orders (user_id, out_trade_no, amount, currency, gateway, status) VALUES (?, ?, ?, "CNY", ?, "pending")');
  $stmt->execute([$user_id, $out_trade_no, $amount, $gateway]);
  return ['ok' => true, 'out_trade_no' => $out_trade_no];
}

function get_recharge_by_out_trade_no(string $out_trade_no): ?array {
  $pdo = getPDO();
  ensure_recharge_table_exists($pdo);
  $stmt = $pdo->prepare('SELECT * FROM recharge_orders WHERE out_trade_no = ?');
  $stmt->execute([$out_trade_no]);
  $row = $stmt->fetch();
  return $row ?: null;
}

function mark_recharge_paid(string $out_trade_no, string $trade_no, ?int $notification_id = null): bool {
  $pdo = getPDO();
  ensure_recharge_table_exists($pdo);
  $stmt = $pdo->prepare('UPDATE recharge_orders SET status="paid", trade_no=?, notification_id=?, paid_at=NOW() WHERE out_trade_no=?');
  return $stmt->execute([$trade_no, $notification_id, $out_trade_no]);
}

function mark_recharge_failed(string $out_trade_no, ?int $notification_id = null): bool {
  $pdo = getPDO();
  ensure_recharge_table_exists($pdo);
  $stmt = $pdo->prepare('UPDATE recharge_orders SET status="failed", notification_id=? WHERE out_trade_no=?');
  return $stmt->execute([$notification_id, $out_trade_no]);
}

function list_recharge_orders(int $limit = 50): array {
  $pdo = getPDO();
  ensure_recharge_table_exists($pdo);
  $stmt = $pdo->prepare('SELECT ro.*, u.username FROM recharge_orders ro LEFT JOIN users u ON ro.user_id = u.id ORDER BY ro.id DESC LIMIT ?');
  $stmt->bindValue(1, $limit, PDO::PARAM_INT);
  $stmt->execute();
  return $stmt->fetchAll();
}