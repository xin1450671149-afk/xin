<?php
require_once __DIR__ . '/db.php';

function get_alipay_config(): ?array {
  $pdo = getPDO();
  $stmt = $pdo->query('SELECT * FROM alipay_config WHERE id=1');
  $row = $stmt->fetch();
  return $row ?: null;
}

function save_alipay_config(array $cfg): void {
  $pdo = getPDO();
  $exists = $pdo->query('SELECT COUNT(*) FROM alipay_config WHERE id=1')->fetchColumn();
  if ((int)$exists === 0) {
    $stmt = $pdo->prepare('INSERT INTO alipay_config (id, app_id, private_key, alipay_public_key, notify_url, return_url, sandbox) VALUES (1, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$cfg['app_id'], $cfg['private_key'], $cfg['alipay_public_key'], $cfg['notify_url'], $cfg['return_url'], (int)($cfg['sandbox'] ?? 1)]);
  } else {
    $stmt = $pdo->prepare('UPDATE alipay_config SET app_id=?, private_key=?, alipay_public_key=?, notify_url=?, return_url=?, sandbox=? WHERE id=1');
    $stmt->execute([$cfg['app_id'], $cfg['private_key'], $cfg['alipay_public_key'], $cfg['notify_url'], $cfg['return_url'], (int)($cfg['sandbox'] ?? 1)]);
  }
}

function log_payment_notification(string $gateway, string $payload, string $status = 'received'): int {
  $pdo = getPDO();
  $stmt = $pdo->prepare('INSERT INTO payment_notifications (gateway, payload, status) VALUES (?, ?, ?)');
  $stmt->execute([$gateway, $payload, $status]);
  return (int)$pdo->lastInsertId();
}