<?php
function getPDO(): PDO {
    $cfg = include __DIR__ . '/config.php';
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $cfg['host'], $cfg['port'], $cfg['dbname'], $cfg['charset']);
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    return new PDO($dsn, $cfg['user'], $cfg['pass'], $options);
}

/**
 * 当目标数据库不存在时，使用不带 dbname 的连接创建数据库。
 */
function ensureDatabaseExists(): void {
    $cfg = include __DIR__ . '/config.php';
    $dsnNoDb = sprintf('mysql:host=%s;port=%d;charset=%s', $cfg['host'], $cfg['port'], $cfg['charset']);
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    $pdo = new PDO($dsnNoDb, $cfg['user'], $cfg['pass'], $options);
    $dbName = preg_replace('/[^a-zA-Z0-9_]/', '', $cfg['dbname']);
    $charset = $cfg['charset'] ?: 'utf8mb4';
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET {$charset} COLLATE {$charset}_general_ci");
}

function runSqlFile(PDO $pdo, string $path): void {
    $sql = file_get_contents($path);
    foreach (array_filter(array_map('trim', preg_split('/;\s*\n/', $sql))) as $stmt) {
        if ($stmt) {
            $pdo->exec($stmt);
        }
    }
}