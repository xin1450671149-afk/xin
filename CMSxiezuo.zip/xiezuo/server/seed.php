<?php
// 初始化数据库并写入默认超级管理员账号
require __DIR__ . '/db.php';

try {
    // 优先尝试连接目标数据库；若不存在则自动创建
    try {
        $pdo = getPDO();
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if (strpos($msg, 'Unknown database') !== false || $e->getCode() == 1049) {
            ensureDatabaseExists();
            $pdo = getPDO();
        } else {
            throw $e;
        }
    }
    // 创建基础表结构
    runSqlFile($pdo, __DIR__ . '/../db/schema.sql');

    // 迁移：确保 tags 表存在 created_at 列
    try {
        $pdo->query("SELECT created_at FROM tags LIMIT 1");
    } catch (Throwable $e) {
        $pdo->exec("ALTER TABLE tags ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    }

    // 迁移：为 users 表补充积分与会员等级字段
    try {
        $pdo->query("SELECT points, membership_level FROM users LIMIT 1");
    } catch (Throwable $e) {
        try { $pdo->exec("ALTER TABLE users ADD COLUMN points INT NOT NULL DEFAULT 0"); } catch (Throwable $e2) {}
        try { $pdo->exec("ALTER TABLE users ADD COLUMN membership_level VARCHAR(32) NOT NULL DEFAULT 'none'"); } catch (Throwable $e3) {}
    }

    // 性能优化：为常用查询字段添加索引（忽略已存在错误）
    $indexes = [
        "ALTER TABLE articles ADD INDEX idx_articles_status (status)",
        "ALTER TABLE articles ADD INDEX idx_articles_created_at (created_at)",
        "ALTER TABLE articles ADD INDEX idx_articles_status_created_at (status, created_at)",
        "ALTER TABLE users ADD INDEX idx_users_created_at (created_at)",
        "ALTER TABLE comments ADD INDEX idx_comments_status (status)",
        "ALTER TABLE comments ADD INDEX idx_comments_created_at (created_at)",
        "ALTER TABLE ai_generation_logs ADD INDEX idx_ai_logs_created_at (created_at)",
        "ALTER TABLE recharge_orders ADD INDEX idx_recharge_status (status)",
        "ALTER TABLE recharge_orders ADD INDEX idx_recharge_created_at (created_at)"
    ];
    foreach ($indexes as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { /* 索引已存在或不兼容时忽略 */ }
    }

    // 确保存在超级管理员角色与权限
    $pdo->exec("INSERT IGNORE INTO roles (name, description) VALUES ('super_admin', '系统超级管理员')");

    $permissions = ['manage_users','manage_roles','manage_permissions','manage_content','manage_system','view_analytics'];
    $stmt = $pdo->prepare('INSERT IGNORE INTO permissions (name, description) VALUES (?, ?)');
    foreach ($permissions as $p) {
        $stmt->execute([$p, 'auto seeded']);
    }

    // 绑定超级管理员角色的所有权限
    $roleId = (int)$pdo->query("SELECT id FROM roles WHERE name='super_admin'")->fetchColumn();
    $permIds = $pdo->query("SELECT id FROM permissions")->fetchAll(PDO::FETCH_COLUMN);
    $bind = $pdo->prepare('INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)');
    foreach ($permIds as $pid) { $bind->execute([$roleId, $pid]); }

    // 创建默认超级管理员账号 admin / 123456（以安全哈希存储）
    $exists = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username=?');
    $exists->execute(['admin']);
    if ((int)$exists->fetchColumn() === 0) {
        $hash = password_hash('123456', PASSWORD_DEFAULT);
        $ins = $pdo->prepare('INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)');
        $ins->execute(['admin', $hash, 'admin@example.com']);
        $userId = (int)$pdo->lastInsertId();
        $map = $pdo->prepare('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)');
        $map->execute([$userId, $roleId]);
        echo "默认超级管理员已创建：用户名 admin\n";
    } else {
        echo "默认超级管理员已存在：用户名 admin\n";
    }

    echo "数据库初始化完成。\n";
    // 默认分类
    $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('默认分类', 'default')");
    echo "默认分类检查完成。\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo "初始化失败：" . $e->getMessage() . "\n";
    exit(1);
}