<?php
// 导出当前数据库为可执行 SQL：支持多模式（full/no_create/structure_only/data_only）
require_once __DIR__ . '/db.php';

function qstr($val): string {
    if ($val === null) return 'NULL';
    if (is_int($val) || is_float($val)) return (string)$val;
    return "'" . addslashes((string)$val) . "'";
}

function getParam(string $key, $default = null) {
    // 支持 CLI 与 Web 两种方式传参
    if (PHP_SAPI === 'cli') {
        global $argv;
        foreach ($argv as $arg) {
            if (strpos($arg, $key.'=') === 0) { return substr($arg, strlen($key)+1); }
        }
        return $default;
    }
    return $_GET[$key] ?? $default;
}

try {
    $cfg = include __DIR__ . '/config.php';
    $pdo = getPDO();
    $dbName = $cfg['dbname'];
    $mode = (string)getParam('mode', 'full'); // full | no_create | structure_only | data_only
    $out = (string)getParam('out', '');
    if ($out === '') {
        $suffix = $mode === 'full' ? 'full' : ($mode === 'no_create' ? 'no_create' : ($mode === 'structure_only' ? 'structure_only' : 'data_only'));
        $out = __DIR__ . '/../db/export_' . $suffix . '.sql';
    }

    $fh = fopen($out, 'w');
    if (!$fh) { throw new RuntimeException('无法写入导出文件：' . $out); }

    // Header
    fwrite($fh, "-- CMS SQL Export\n");
    fwrite($fh, "-- Mode: {$mode}\n");
    fwrite($fh, "-- Generated at: " . date('Y-m-d H:i:s') . "\n\n");
    if ($mode !== 'no_create' && $mode !== 'data_only') {
        fwrite($fh, "CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;\n");
        fwrite($fh, "USE `{$dbName}`;\n");
    }
    fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");

    // 获取所有表
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        // CREATE TABLE（结构导出）
        if ($mode !== 'data_only') {
            $row = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch();
            $createSql = $row['Create Table'] ?? $row[1] ?? '';
            if ($createSql) {
                if ($mode !== 'structure_only') { fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n"); }
                fwrite($fh, $createSql . ";\n\n");
            }
        }

        // 数据导出
        if ($mode !== 'structure_only') {
            $stmt = $pdo->query("SELECT * FROM `{$table}`");
            $first = $stmt->fetch(PDO::FETCH_ASSOC);
            $cols = array_keys($first ?: []);
            if (!empty($cols)) {
                $colList = '`' . implode('`,`', $cols) . '`';
                // 写第一行
                if ($first) {
                    $vals = [];
                    foreach ($cols as $c) { $vals[] = qstr($first[$c] ?? null); }
                    fwrite($fh, "INSERT INTO `{$table}` ({$colList}) VALUES (" . implode(',', $vals) . ");\n");
                }
                // 继续写剩余行
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $vals = [];
                    foreach ($cols as $c) { $vals[] = qstr($row[$c] ?? null); }
                    fwrite($fh, "INSERT INTO `{$table}` ({$colList}) VALUES (" . implode(',', $vals) . ");\n");
                }
                fwrite($fh, "\n");
            }
        }
    }

    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
    echo "导出完成：{$out}\n";
} catch (Throwable $e) {
    http_response_code(500);
    echo '导出失败：' . $e->getMessage() . "\n";
    exit(1);
}
?>