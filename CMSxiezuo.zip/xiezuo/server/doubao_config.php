<?php
require_once __DIR__ . '/db.php';

function ensure_doubao_table(): void {
  $pdo = getPDO();
  $sql = "CREATE TABLE IF NOT EXISTS doubao_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('image','video') NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 0,
    api_key VARCHAR(255) NOT NULL,
    model_id VARCHAR(255) NOT NULL,
    endpoint_url VARCHAR(255) NOT NULL,
    points_per_unit INT NOT NULL DEFAULT 100,
    pricing_unit ENUM('per_image','per_video') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_type (type)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
  $pdo->exec($sql);
  // Seed defaults for image/video rows if missing
  $defaults = [
    'image' => [
      'enabled' => 0,
      'api_key' => '',
      'model_id' => 'doubao-seedream-4-0-250828',
      'endpoint_url' => 'https://ark.cn-beijing.volces.com/api/v3/images/generations',
      'points_per_unit' => 100,
      'pricing_unit' => 'per_image',
    ],
    'video' => [
      'enabled' => 0,
      'api_key' => '',
      'model_id' => 'doubao-seedance-1-0-pro-250528',
      'endpoint_url' => 'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks',
      'points_per_unit' => 100,
      'pricing_unit' => 'per_video',
    ],
  ];
  foreach ($defaults as $type => $d) {
    $stmt = $pdo->prepare('SELECT id FROM doubao_config WHERE type=?');
    $stmt->execute([$type]);
    if (!$stmt->fetch()) {
      $ins = $pdo->prepare('INSERT INTO doubao_config (type, enabled, api_key, model_id, endpoint_url, points_per_unit, pricing_unit) VALUES (?, ?, ?, ?, ?, ?, ?)');
      $ins->execute([$type, $d['enabled'], $d['api_key'], $d['model_id'], $d['endpoint_url'], $d['points_per_unit'], $d['pricing_unit']]);
    }
  }
}

function get_doubao_config(string $type): array {
  ensure_doubao_table();
  $pdo = getPDO();
  $stmt = $pdo->prepare('SELECT * FROM doubao_config WHERE type=?');
  $stmt->execute([$type]);
  $row = $stmt->fetch();
  return $row ?: [];
}

function save_doubao_config(string $type, array $fields): void {
  ensure_doubao_table();
  $pdo = getPDO();
  $existing = get_doubao_config($type);
  $enabled = !empty($fields['enabled']) ? 1 : 0;
  $api_key = trim((string)($fields['api_key'] ?? ''));
  $model_id = trim((string)($fields['model_id'] ?? ''));
  $endpoint_url = trim((string)($fields['endpoint_url'] ?? ''));
  $points = (int)($fields['points_per_unit'] ?? 100);
  if ($points <= 0) { $points = 1; }
  $pricing_unit = in_array(($fields['pricing_unit'] ?? ''), ['per_image','per_video'], true) ? $fields['pricing_unit'] : ($type === 'image' ? 'per_image' : 'per_video');
  if ($existing) {
    $stmt = $pdo->prepare('UPDATE doubao_config SET enabled=?, api_key=?, model_id=?, endpoint_url=?, points_per_unit=?, pricing_unit=? WHERE type=?');
    $stmt->execute([$enabled, $api_key, $model_id, $endpoint_url, $points, $pricing_unit, $type]);
  } else {
    $stmt = $pdo->prepare('INSERT INTO doubao_config (type, enabled, api_key, model_id, endpoint_url, points_per_unit, pricing_unit) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$type, $enabled, $api_key, $model_id, $endpoint_url, $points, $pricing_unit]);
  }
}

// --- Connectivity test for Doubao image API ---
function test_doubao_image_api(): array {
  $cfg = get_doubao_config('image');
  if (empty($cfg)) { return ['ok' => false, 'error' => 'config_missing']; }
  $ch = curl_init($cfg['endpoint_url']);
  $payloadArr = [
    'model' => $cfg['model_id'],
    'prompt' => 'ping',
    'stream' => false,
    // 关闭组图功能，按官方文档允许的最小配置
    'sequential_image_generation' => 'disabled',
    // 指定像素分辨率，符合文档范围
    'size' => '2048x2048',
  ];
  $payload = json_encode($payloadArr, JSON_UNESCAPED_UNICODE);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
      'Authorization: Bearer ' . $cfg['api_key'],
      'Content-Type: application/json',
      'Accept: application/json'
    ],
    // 更宽松的超时并强制IPv4，防止IPv6网络导致的连接问题
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
    CURLOPT_FOLLOWLOCATION => true,
  ]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $info = [
    'url' => curl_getinfo($ch, CURLINFO_EFFECTIVE_URL),
    'content_type' => curl_getinfo($ch, CURLINFO_CONTENT_TYPE),
    'size_download' => curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD),
  ];
  curl_close($ch);
  if ($err) {
    $out = ['ok' => false, 'status' => $code, 'error' => $err] + $info;
    // 针对常见超时错误给出更明确提示
    if (stripos($err, 'timed out') !== false) {
      $out['hint'] = '网络连接超时：已启用IPv4与更长超时，如仍失败请检查服务器到 ark.cn-beijing.volces.com 的网络或证书。';
    }
    return $out;
  }
  return ['ok' => ($code >= 200 && $code < 300), 'status' => $code, 'sample' => substr((string)$body, 0, 600)] + $info;
}

// --- Connectivity test for Doubao video API ---
function test_doubao_video_api(): array {
  $cfg = get_doubao_config('video');
  if (empty($cfg)) { return ['ok' => false, 'error' => 'config_missing']; }
  $ch = curl_init($cfg['endpoint_url']);
  $payload = json_encode([
    'model' => $cfg['model_id'],
    'content' => [
      ['type' => 'text', 'text' => 'ping']
    ]
  ], JSON_UNESCAPED_UNICODE);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
      'Authorization: Bearer ' . $cfg['api_key'],
      'Content-Type: application/json',
      'Accept: application/json'
    ],
    CURLOPT_TIMEOUT => 10,
  ]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($err) { return ['ok' => false, 'status' => $code, 'error' => $err]; }
  return ['ok' => ($code >= 200 && $code < 300), 'status' => $code, 'sample' => substr((string)$body, 0, 600)];
}

?>