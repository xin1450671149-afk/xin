<?php
require_once __DIR__ . '/db.php';

function aggregate_by_day(PDO $pdo, string $table, string $dateColumn, int $days = 30, array $extraWhere = []): array {
    $start = (new DateTimeImmutable())->modify('-'.($days-1).' days')->setTime(0,0,0);
    $params = [];
    $where = "WHERE $dateColumn >= ?";
    $params[] = $start->format('Y-m-d 00:00:00');
    foreach ($extraWhere as $cond => $val) { $where .= " AND $cond"; $params = array_merge($params, (array)$val); }
    $sql = "SELECT DATE($dateColumn) AS d, COUNT(*) AS c FROM $table $where GROUP BY DATE($dateColumn) ORDER BY d";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    // normalize to fill missing days
    $map = [];
    foreach ($rows as $r) { $map[$r['d']] = (int)$r['c']; }
    $out = [];
    for ($i=0; $i<$days; $i++) {
        $d = $start->modify("+$i days")->format('Y-m-d');
        $out[] = ['date' => $d, 'count' => $map[$d] ?? 0];
    }
    return $out;
}

function get_article_stats(int $days = 30): array {
    $pdo = getPDO();
    $published = aggregate_by_day($pdo, 'articles', 'created_at', $days, ['status = ?' => ['published']]);
    $draft = aggregate_by_day($pdo, 'articles', 'created_at', $days, ['status = ?' => ['draft']]);
    return ['published' => $published, 'draft' => $draft];
}

function get_user_stats(int $days = 30): array {
    $pdo = getPDO();
    return aggregate_by_day($pdo, 'users', 'created_at', $days);
}

function get_comment_stats(int $days = 30): array {
    $pdo = getPDO();
    return aggregate_by_day($pdo, 'comments', 'created_at', $days);
}