<?php
require_once __DIR__ . '/db.php';

function start_session(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

// --- ACL helpers ---
function load_user_permissions(int $userId): array {
    $pdo = getPDO();
    $sql = 'SELECT DISTINCT p.name
            FROM user_roles ur
            JOIN role_permissions rp ON ur.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE ur.user_id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
}

function user_permissions(): array {
    start_session();
    $perms = $_SESSION['permissions'] ?? null;
    if ($perms === null && !empty($_SESSION['user_id'])) {
        $perms = load_user_permissions((int)$_SESSION['user_id']);
        $_SESSION['permissions'] = $perms;
    }
    return is_array($perms) ? $perms : [];
}

function has_permission(string $perm): bool {
    return in_array($perm, user_permissions(), true);
}

function require_permission(string $perm): void {
    require_login();
    if (!has_permission($perm)) {
        http_response_code(403);
        echo 'Forbidden: insufficient permissions';
        exit;
    }
}

function login(string $username, string $password): bool {
    start_session();
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if (!$user) return false;
    if (!password_verify($password, $user['password_hash'])) return false;
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['username'] = $user['username'];
    // 加载并缓存用户权限
    $_SESSION['permissions'] = load_user_permissions((int)$user['id']);
    return true;
}

function require_login(): void {
    start_session();
    if (empty($_SESSION['user_id'])) {
        header('Location: /login.html?error=auth');
        exit;
    }
}

function logout(): void {
    start_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

// --- Roles CRUD ---
function list_roles(): array {
    $pdo = getPDO();
    return $pdo->query('SELECT id, name, description FROM roles ORDER BY id ASC')->fetchAll();
}

function get_role(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, name, description FROM roles WHERE id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function create_role(string $name, ?string $description = null): int {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO roles (name, description) VALUES (?, ?)');
    $stmt->execute([$name, $description]);
    return (int)$pdo->lastInsertId();
}

function update_role(int $id, string $name, ?string $description = null): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE roles SET name=?, description=? WHERE id=?');
    $stmt->execute([$name, $description, $id]);
}

function delete_role(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM roles WHERE id=?');
    $stmt->execute([$id]);
}

// --- Permissions CRUD ---
function list_permissions_all(): array {
    $pdo = getPDO();
    return $pdo->query('SELECT id, name, description FROM permissions ORDER BY id ASC')->fetchAll();
}

function get_permission(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, name, description FROM permissions WHERE id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

// --- Users basic management ---
function list_users(): array {
    $pdo = getPDO();
    return $pdo->query('SELECT id, username, email, points, membership_level, created_at FROM users ORDER BY id DESC')->fetchAll();
}

function create_user(string $username, string $password, ?string $email = null): int {
    $pdo = getPDO();
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)');
    $stmt->execute([$username, $hash, $email]);
    return (int)$pdo->lastInsertId();
}

function delete_user(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
    $stmt->execute([$id]);
}

// --- Users detail & updates ---
function get_user(int $id): ?array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT id, username, email, points, membership_level, created_at FROM users WHERE id=?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function update_user_email(int $id, ?string $email): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE users SET email=? WHERE id=?');
    $stmt->execute([$email, $id]);
}

function update_user_password(int $id, string $newPassword): void {
    $pdo = getPDO();
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?');
    $stmt->execute([$hash, $id]);
}

function adjust_user_points(int $id, int $delta): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE users SET points = GREATEST(0, points + ?) WHERE id=?');
    $stmt->execute([$delta, $id]);
}

function set_user_membership(int $id, string $level): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE users SET membership_level=? WHERE id=?');
    $stmt->execute([$level, $id]);
}

function create_permission(string $name, ?string $description = null): int {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO permissions (name, description) VALUES (?, ?)');
    $stmt->execute([$name, $description]);
    return (int)$pdo->lastInsertId();
}

function update_permission(int $id, string $name, ?string $description = null): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('UPDATE permissions SET name=?, description=? WHERE id=?');
    $stmt->execute([$name, $description, $id]);
}

function delete_permission(int $id): void {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM permissions WHERE id=?');
    $stmt->execute([$id]);
}

// --- Role-Permissions mapping ---
function get_role_permission_ids(int $roleId): array {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT permission_id FROM role_permissions WHERE role_id=?');
    $stmt->execute([$roleId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function set_role_permissions(int $roleId, array $permissionIds): void {
    $pdo = getPDO();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('DELETE FROM role_permissions WHERE role_id=?')->execute([$roleId]);
        if (!empty($permissionIds)) {
            $stmt = $pdo->prepare('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)');
            foreach ($permissionIds as $pid) {
                $stmt->execute([$roleId, (int)$pid]);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}