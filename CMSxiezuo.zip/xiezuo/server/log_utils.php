<?php

function tail_lines(string $file, int $lines = 100): array {
    if (!is_file($file) || $lines <= 0) return [];
    $fh = @fopen($file, 'r');
    if (!$fh) return [];
    $buffer = '';
    $chunkSize = 8192;
    $pos = -1;
    $lineCount = 0;
    fseek($fh, 0, SEEK_END);
    $fileSize = ftell($fh);
    while ($lineCount <= $lines && -$pos < $fileSize) {
        $pos -= $chunkSize;
        if (-$pos > $fileSize) { $pos = -$fileSize; }
        fseek($fh, $pos, SEEK_END);
        $buffer = fread($fh, min($chunkSize, $fileSize + $pos)) . $buffer;
        $lineCount = substr_count($buffer, "\n");
    }
    fclose($fh);
    $all = preg_split('/\r?\n/', rtrim($buffer));
    if (!$all) return [];
    return array_slice($all, max(0, count($all) - $lines));
}