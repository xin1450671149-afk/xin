/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './public/**/*.php',
    './public/**/*.html',
    './public/**/*.js',
    './server/**/*.php',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}