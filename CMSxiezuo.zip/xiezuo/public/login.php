<?php
require_once __DIR__ . '/../server/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /login.html');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    header('Location: /login.html?error=1');
    exit;
}

if (login($username, $password)) {
    header('Location: /dashboard.php');
    exit;
}

header('Location: /login.html?error=1');
exit;