<?php
require_once __DIR__ . '/../server/auth.php';
require_once __DIR__ . '/../server/db.php';
require_once __DIR__ . '/../server/log_utils.php';
require_login();

// 实时统计数据
$pdo = getPDO();
// 文章总数/草稿数
$articles_total = (int)$pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();
$articles_draft = (int)$pdo->query("SELECT COUNT(*) FROM articles WHERE status='draft'")->fetchColumn();
// 今日已发布文章与昨日对比
$today_published = (int)$pdo->query("SELECT COUNT(*) FROM articles WHERE status='published' AND created_at >= CURDATE() AND created_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)")->fetchColumn();
$yesterday_published = (int)$pdo->query("SELECT COUNT(*) FROM articles WHERE status='published' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND created_at < CURDATE()")->fetchColumn();
$delta_pub = $today_published - $yesterday_published;
// 用户总数与最近7天新增
$users_total = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$users_week = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();
// 待审核评论数
$pending_comments = (int)$pdo->query("SELECT COUNT(*) FROM comments WHERE status='pending'")->fetchColumn();

// 最近日志（最多8条）
$log_lines = [];
$logFile = __DIR__ . '/../server/storage/logs/app.log';
if (file_exists($logFile)) {
  $log_lines = tail_lines($logFile, 8);
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>CMS 管理后台 · 仪表盘</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/styles.css" />
    <script src="/assets/vendor/chart.umd.min.js"></script>
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <!-- Sidebar -->
      <aside id="sidebar" class="w-72 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <div class="inline-flex items-center gap-2">
            <div class="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 grid place-items-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 14v-3h3l-4-5v3H9l4 5z" /></svg>
            </div>
            <span class="text-lg font-semibold">CMS 管理后台</span>
          </div>
        </div>
        <nav class="px-3 py-3 space-y-6 overflow-y-auto h-[calc(100vh-4rem)]">
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">主页</p>
            <a class="nav-item" href="#">首页</a>
          </div>
          <?php if (has_permission('manage_content')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">内容管理</p>
            <a class="nav-item" href="/admin/articles.php">文章管理</a>
            <a class="nav-item" href="/admin/categories.php">分类管理</a>
            <a class="nav-item" href="/admin/tags.php">标签管理</a>
            <a class="nav-item" href="/admin/comments.php">评论管理</a>
            <a class="nav-item" href="#">链接管理</a>
          </div>
          <?php endif; ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">用户与权限</p>
            <?php if (has_permission('manage_users')): ?><a class="nav-item" href="/admin/users.php">用户列表</a><?php endif; ?>
            <?php if (has_permission('manage_roles')): ?><a class="nav-item" href="/admin/roles.php">角色管理</a><?php endif; ?>
            <?php if (has_permission('manage_permissions')): ?><a class="nav-item" href="/admin/permissions.php">权限管理</a><?php endif; ?>
          </div>
          <?php if (has_permission('manage_system')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">系统管理</p>
            <a class="nav-item" href="/admin/system_config.php">配置管理</a>
            <a class="nav-item" href="/admin/system_cache.php">缓存管理</a>
            <a class="nav-item" href="/admin/system_logs.php">日志管理</a>
            <a class="nav-item" href="/admin/system_backup.php">备份管理</a>
          </div>
          <?php endif; ?>
          <?php if (has_permission('view_analytics')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">统计分析</p>
            <a class="nav-item" href="/admin/analytics.php">访问统计</a>
            <a class="nav-item" href="/admin/analytics.php">评论统计</a>
            <a class="nav-item" href="/admin/analytics.php">流量统计</a>
            <a class="nav-item" href="/admin/analytics.php">注册统计</a>
            <a class="nav-item" href="/admin/analytics.php">登录统计</a>
          </div>
          <?php endif; ?>
          <?php if (has_permission('manage_system')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">AI 生成记录</p>
            <a class="nav-item" href="/admin/ai_logs.php">生成记录</a>
            <a class="nav-item" href="/admin/ai_image.php">图片生成</a>
            <a class="nav-item" href="/admin/ai_audio.php">语音生成</a>
            <a class="nav-item" href="/admin/ai_video.php">视频生成</a>
          </div>
          <?php endif; ?>
          <?php if (has_permission('manage_system')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">模型配置</p>
            <a class="nav-item" href="/admin/ai_models.php">模型列表</a>
            <a class="nav-item" href="/admin/ai_models.php">one-api 接口配置</a>
            <a class="nav-item" href="/admin/doubao_config.php">豆包模型配置</a>
          </div>
          <?php endif; ?>
          <?php if (has_permission('manage_system')): ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">支付配置</p>
            <a class="nav-item" href="/admin/payment_alipay.php">支付宝</a>
            <a class="nav-item" href="/admin/payment_alipay.php">支付参数</a>
            <a class="nav-item" href="/admin/payment_notify_test.php">回调与通知</a>
            <a class="nav-item" href="/admin/recharge_orders.php">充值订单</a>
          </div>
          <?php endif; ?>
          <div>
            <p class="px-3 text-xs uppercase tracking-widest text-slate-400">其他配置</p>
            <a class="nav-item" href="/admin/system_site.php">网站配置</a>
            <a class="nav-item" href="/admin/system_email.php">邮箱配置</a>
            <a class="nav-item" href="/admin/system_sms.php">短信配置</a>
            <a class="nav-item" href="/admin/system_logs.php">日志配置</a>
          </div>
        </nav>
      </aside>

      <!-- Main -->
      <div class="flex-1">
        <!-- Topbar -->
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <div class="flex items-center gap-3">
            <button id="sidebarToggle" class="rounded-lg border border-slate-700 px-3 py-2 hover:bg-slate-800">菜单</button>
            <h2 class="text-lg font-semibold">仪表盘</h2>
          </div>
          <div class="flex items-center gap-3">
            <button id="themeToggle" class="rounded-lg border border-slate-700 px-3 py-2 hover:bg-slate-800">主题</button>
            <a href="./logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
          </div>
        </div>

        <!-- Content -->
        <div class="p-6 space-y-6">
          <!-- KPI cards -->
          <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <div class="card">
              <p class="text-slate-400 text-sm">今日新增文章</p>
              <p class="mt-2 text-3xl font-semibold"><?php echo number_format($today_published); ?></p>
              <p class="mt-1 text-xs <?php echo $delta_pub>=0 ? 'text-emerald-400' : 'text-rose-400'; ?>"><?php echo ($delta_pub>=0 ? '+' : '') . $delta_pub; ?> 较昨日</p>
            </div>
            <div class="card">
              <p class="text-slate-400 text-sm">文章总数</p>
              <p class="mt-2 text-3xl font-semibold"><?php echo number_format($articles_total); ?></p>
              <p class="mt-1 text-xs text-slate-400">含草稿 <?php echo number_format($articles_draft); ?></p>
            </div>
            <div class="card">
              <p class="text-slate-400 text-sm">注册用户</p>
              <p class="mt-2 text-3xl font-semibold"><?php echo number_format($users_total); ?></p>
              <p class="mt-1 text-xs text-emerald-400">+<?php echo number_format($users_week); ?> 本周</p>
            </div>
            <div class="card">
              <p class="text-slate-400 text-sm">待审核评论</p>
              <p class="mt-2 text-3xl font-semibold"><?php echo number_format($pending_comments); ?></p>
              <p class="mt-1 text-xs text-amber-400">需处理</p>
            </div>
          </div>

          <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <div class="col-span-2 card">
              <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold">文章发布趋势</h3>
                <select id="rangeDash" aria-label="时间范围" class="rounded-md bg-slate-800 border border-slate-700 px-2 py-1 text-sm">
                  <option value="7">最近 7 天</option>
                  <option value="30">最近 30 天</option>
                </select>
              </div>
              <canvas id="trafficChart" class="mt-4"></canvas>
            </div>
            <div class="card">
              <h3 class="text-lg font-semibold">系统状态</h3>
              <ul class="mt-3 space-y-2 text-sm text-slate-300">
                <li>数据库连接 <span class="ml-2 rounded bg-emerald-500/20 text-emerald-400 px-2 py-0.5">正常</span></li>
                <li>缓存服务 <span class="ml-2 rounded bg-amber-500/20 text-amber-400 px-2 py-0.5">警告</span></li>
                <li>存储空间 <span class="ml-2 rounded bg-sky-500/20 text-sky-400 px-2 py-0.5">72%</span></li>
              </ul>
            </div>
          </div>

          <div class="card">
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-semibold">最近日志</h3>
              <a href="/admin/system_logs.php" class="rounded-md bg-slate-800 border border-slate-700 px-2 py-1 text-sm">查看全部</a>
            </div>
            <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <?php if (!empty($log_lines)): ?>
                <?php foreach ($log_lines as $line): ?>
                  <div class="rounded-lg bg-slate-800/60 p-4 whitespace-pre-wrap break-words"><?php echo htmlspecialchars($line); ?></div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="text-slate-400">暂无日志记录</div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="./assets/app.js"></script>
    <script>
      async function fetchArticles(days) {
        const res = await fetch(`/admin/api/analytics.php?metric=articles&days=${days}`);
        const j = await res.json();
        if (!j.ok) throw new Error(j.error || '加载失败');
        const labels = j.data.published.map(x => x.date);
        const data = j.data.published.map(x => x.count);
        return { labels, data };
      }

      const ctx = document.getElementById('trafficChart');
      const sel = document.getElementById('rangeDash');
      async function renderChart(days) {
        if (!ctx) return;
        const { labels, data } = await fetchArticles(days).catch(() => ({ labels: [], data: [] }));
        new Chart(ctx, {
          type: 'line',
          data: {
            labels,
            datasets: [{
              label: '文章发布量',
              data,
              borderColor: '#22d3ee',
              backgroundColor: 'rgba(34, 211, 238, 0.15)',
              tension: 0.35,
              fill: true,
            }]
          },
          options: {
            plugins: { legend: { labels: { color: '#cbd5e1' } } },
            scales: {
              x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } },
              y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } },
            }
          }
        });
      }
      if (sel) {
        sel.addEventListener('change', e => renderChart(parseInt(e.target.value,10)));
        renderChart(parseInt(sel.value || '7',10));
      } else {
        renderChart(7);
      }
    </script>
  </body>
  <style>
    .nav-item { display:block; margin-top:0.25rem; padding:0.5rem 0.75rem; border-radius:0.5rem; color:#cbd5e1; }
    .nav-item:hover { background-color: rgba(30,41,59,0.7); color:#fff; }
    .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
  </style>
</html>