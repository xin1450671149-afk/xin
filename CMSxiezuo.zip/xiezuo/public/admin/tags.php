<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$tags = list_tags();
$error = $_GET['error'] ?? '';
$ok = isset($_GET['ok']);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>标签管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">标签管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
          <a class="nav-item" href="/admin/articles.php">文章管理</a>
          <a class="nav-item" href="/admin/categories.php">分类管理</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">标签列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?>
            <div class="xl:col-span-3 rounded-lg bg-emerald-900/30 border border-emerald-700 px-3 py-2 text-sm">已保存</div>
          <?php endif; ?>
          <?php if ($error): ?>
            <div class="xl:col-span-3 rounded-lg bg-rose-900/30 border border-rose-700 px-3 py-2 text-sm">操作失败：<?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <section class="xl:col-span-2 card">
            <table class="w-full text-sm">
              <thead>
                <tr class="text-slate-400">
                  <th class="text-left p-2">名称</th>
                  <th class="text-left p-2">创建时间</th>
                  <th class="text-left p-2">操作</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($tags as $t): ?>
                <tr class="border-t border-slate-800">
                  <td class="p-2"><?= htmlspecialchars($t['name']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($t['created_at'] ?? '') ?></td>
                  <td class="p-2">
                    <a href="/admin/tag_edit.php?id=<?= (int)$t['id'] ?>" class="text-cyan-400">编辑</a>
                    <span class="mx-2 text-slate-600">|</span>
                    <a href="/admin/tag_delete.php?id=<?= (int)$t['id'] ?>" class="text-rose-400" onclick="return confirm('确认删除该标签？');">删除</a>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($tags)): ?>
                <tr><td class="p-3 text-slate-400" colspan="3">暂无标签</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">新增标签</h3>
            <form action="/admin/tag_create.php" method="post" class="mt-4 space-y-3">
              <div>
                <label class="block text-sm">名称</label>
                <input name="name" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">创建</button>
            </form>
          </section>
        </div>
      </main>
    </div>
    <style>
      .nav-item { display:block; margin-top:0.25rem; padding:0.5rem 0.75rem; border-radius:0.5rem; color:#cbd5e1; }
      .nav-item:hover { background-color: rgba(30,41,59,0.7); color:#fff; }
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
  </body>
</html>