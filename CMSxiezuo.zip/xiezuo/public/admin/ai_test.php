<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');
$id = (int)($_GET['id'] ?? 0);
$result = null;
if ($id) {
  try { $result = test_one_api_connectivity($id); } catch (Throwable $e) { $result = ['ok'=>false,'error'=>$e->getMessage()]; }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>AI 接口测试 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-3xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">AI 接口测试</h1>
        <a href="/admin/ai_models.php" class="rounded-lg bg-slate-800 px-3 py-2">返回模型列表</a>
      </div>
      <div class="card">
        <p class="text-sm text-slate-400">测试目标模型 ID：<?= (int)$id ?></p>
        <?php if ($result): ?>
          <?php if (!empty($result['ok'])): ?>
            <p class="mt-2 text-emerald-400">连通成功 · HTTP <?= (int)($result['status'] ?? 200) ?></p>
          <?php else: ?>
            <p class="mt-2 text-rose-400">连通失败：<?= htmlspecialchars($result['error'] ?? ('HTTP '.(int)($result['status'] ?? 0))) ?></p>
          <?php endif; ?>
          <pre class="mt-3 whitespace-pre-wrap text-xs text-slate-300 overflow-x-auto bg-slate-800/60 p-3 rounded"><?= htmlspecialchars((string)($result['body'] ?? '')) ?></pre>
        <?php else: ?>
          <p class="mt-2 text-slate-400">打开页面即自动测试，若无结果请检查模型配置。</p>
        <?php endif; ?>
      </div>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }</style>
  </body>
</html>