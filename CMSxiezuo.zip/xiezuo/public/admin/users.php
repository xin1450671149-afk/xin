<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_users');

$users = list_users();
$error = $_GET['error'] ?? '';
$ok = isset($_GET['ok']);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>用户管理 · CMS 管理后台</title>
    <link rel="stylesheet" href="../assets/styles.css" />
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">用户管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">用户列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?><div class="xl:col-span-3 card-notice-ok">已保存</div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error">操作失败：<?= htmlspecialchars($error) ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <table class="w-full text-sm">
              <thead>
                <tr class="text-slate-400">
                  <th class="text-left p-2">ID</th>
                  <th class="text-left p-2">用户名</th>
                  <th class="text-left p-2">邮箱</th>
                  <th class="text-left p-2">积分</th>
                  <th class="text-left p-2">会员等级</th>
                  <th class="text-left p-2">注册时间</th>
                  <th class="text-left p-2">操作</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($users as $u): ?>
                <tr class="border-t border-slate-800">
                  <td class="p-2"><?= (int)$u['id'] ?></td>
                  <td class="p-2"><?= htmlspecialchars($u['username']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($u['email'] ?? '') ?></td>
                  <td class="p-2"><?= (int)($u['points'] ?? 0) ?></td>
                  <td class="p-2"><?= htmlspecialchars($u['membership_level'] ?? 'none') ?></td>
                  <td class="p-2"><?= htmlspecialchars($u['created_at']) ?></td>
                  <td class="p-2">
                    <button class="text-cyan-400" onclick="openEdit(<?= (int)$u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>', '<?= htmlspecialchars($u['email'] ?? '') ?>', <?= (int)($u['points'] ?? 0) ?>, '<?= htmlspecialchars($u['membership_level'] ?? 'none') ?>')">编辑</button>
                    <a href="/admin/user_delete.php?id=<?= (int)$u['id'] ?>" class="text-rose-400" onclick="return confirm('确认删除该用户？');">删除</a>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($users)): ?>
                <tr><td class="p-3 text-slate-400" colspan="5">暂无用户</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">新增用户</h3>
            <form action="/admin/user_create.php" method="post" class="mt-4 space-y-3">
              <div>
                <label class="block text-sm">用户名</label>
                <input name="username" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">密码</label>
                <input type="password" name="password" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
               <div>
                <label class="block text-sm">邮箱</label>
                <input type="email" name="email" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">创建</button>
            </form>
          </section>

          <!-- 编辑弹窗 -->
          <div id="editModal" class="fixed inset-0 bg-black/40 backdrop-blur hidden">
            <div class="max-w-lg mx-auto mt-24 rounded-xl bg-slate-900 border border-slate-800 p-4">
              <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold">编辑用户</h3>
                <button class="rounded bg-slate-800 px-2 py-1" onclick="closeEdit()">关闭</button>
              </div>
              <form class="mt-4 space-y-3" method="post" action="/admin/user_update.php">
                <input type="hidden" name="id" id="edit_id" />
                <div>
                  <label class="block text-sm">用户名</label>
                  <input id="edit_username" disabled class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">邮箱</label>
                  <input name="email" id="edit_email" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">新密码（留空不改）</label>
                  <input type="password" name="new_password" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">积分增减（可负数）</label>
                  <input type="number" name="points_delta" id="edit_points" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">会员等级</label>
                  <select name="membership_level" id="edit_level" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                    <option value="none">无</option>
                    <option value="bronze">青铜</option>
                    <option value="silver">白银</option>
                    <option value="gold">黄金</option>
                    <option value="platinum">铂金</option>
                    <option value="vip">VIP</option>
                  </select>
                </div>
                <div class="pt-2">
                  <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存修改</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
    <script>
      function openEdit(id, username, email, points, level) {
        document.getElementById('edit_id').value = id;
        document.getElementById('edit_username').value = username;
        document.getElementById('edit_email').value = email || '';
        document.getElementById('edit_points').value = 0; // 默认增减 0
        document.getElementById('edit_level').value = level || 'none';
        document.getElementById('editModal').classList.remove('hidden');
      }
      function closeEdit() {
        document.getElementById('editModal').classList.add('hidden');
      }
    </script>
  </body>
</html>