<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/log_utils.php';
require_login();
require_permission('manage_system');

$logFile = __DIR__ . '/../../server/storage/logs/app.log';
if (!is_dir(dirname($logFile))) { @mkdir(dirname($logFile), 0777, true); }

$msg = null;
if (isset($_GET['action'])) {
  $action = $_GET['action'];
  if ($action === 'clear') {
    file_put_contents($logFile, "");
    $msg = '日志已清空';
  } elseif ($action === 'seed') {
    $seed = "[INFO] 系统启动完成\n[WARN] 缓存命中率较低\n[ERROR] 邮件服务响应超时\n";
    file_put_contents($logFile, $seed, FILE_APPEND);
    $msg = '已追加示例日志';
  }
}

$logs = file_exists($logFile) ? tail_lines($logFile, 200) : [];
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>日志管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">日志管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">系统日志</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($msg): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-semibold">最近日志</h3>
              <div class="flex items-center gap-2">
                <a href="/admin/system_logs.php?action=seed" class="rounded-lg bg-sky-600 px-3 py-1.5 text-sm">追加示例</a>
                <a href="/admin/system_logs.php?action=clear" class="rounded-lg bg-rose-600 px-3 py-1.5 text-sm">清空</a>
              </div>
            </div>
            <div class="mt-4 grid grid-cols-1 gap-2 text-sm">
              <?php if (!empty($logs)): ?>
                <?php foreach ($logs as $line): ?>
                  <div class="rounded-lg bg-slate-800/60 p-3 whitespace-pre-wrap"><?php echo htmlspecialchars($line); ?></div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="text-slate-400">暂无日志记录</div>
              <?php endif; ?>
            </div>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">说明</h3>
            <p class="mt-2 text-sm text-slate-300">此页面读取 <code>server/storage/logs/app.log</code> 文件。实际项目可接入系统日志或数据库表。</p>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>