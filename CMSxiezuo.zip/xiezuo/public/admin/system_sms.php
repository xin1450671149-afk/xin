<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$configPath = __DIR__ . '/../../server/config_sms.php';
$cfg = file_exists($configPath) ? include $configPath : [
  'provider' => '', 'endpoint' => '',
  'api_key' => '', 'api_secret' => '',
  'sign_name' => '', 'template_id' => ''
];
$ok = false; $error = null; $msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $provider = trim($_POST['provider'] ?? '');
  $endpoint = trim($_POST['endpoint'] ?? '');
  $api_key = trim($_POST['api_key'] ?? '');
  $api_secret = trim($_POST['api_secret'] ?? '');
  $sign_name = trim($_POST['sign_name'] ?? '');
  $template_id = trim($_POST['template_id'] ?? '');

  if ($provider === '' || $api_key === '' || $sign_name === '') {
    $error = '请填写短信服务商、API Key 与签名。';
  } else {
    $newCfg = compact('provider','endpoint','api_key','api_secret','sign_name','template_id');
    $content = "<?php\n// 短信配置：由系统短信配置页面自动生成\nreturn " . var_export($newCfg, true) . ";\n";
    $writable = is_writable($configPath) || is_writable(dirname($configPath));
    if (!$writable) { $error = '配置文件不可写：server/config_sms.php'; }
    else {
      $bytes = @file_put_contents($configPath, $content);
      if ($bytes === false) { $error = '写入失败，请检查权限与磁盘空间。'; }
      else { $ok = true; $msg = '短信配置已保存。'; $cfg = $newCfg; }
    }
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>短信配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">短信配置</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">服务商设置</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <form method="post" class="space-y-3">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm">服务商</label>
                  <input name="provider" placeholder="如 aliyun、tencent、twilio" value="<?php echo htmlspecialchars($cfg['provider'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">API Endpoint</label>
                  <input name="endpoint" value="<?php echo htmlspecialchars($cfg['endpoint'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">API Key</label>
                  <input name="api_key" value="<?php echo htmlspecialchars($cfg['api_key'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">API Secret</label>
                  <input name="api_secret" value="<?php echo htmlspecialchars($cfg['api_secret'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">签名</label>
                  <input name="sign_name" value="<?php echo htmlspecialchars($cfg['sign_name'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">模板 ID</label>
                  <input name="template_id" value="<?php echo htmlspecialchars($cfg['template_id'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
              </div>
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
            </form>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">说明</h3>
            <p class="mt-2 text-sm text-slate-300">此页面写入 <code>server/config_sms.php</code>。实际项目可扩展发送测试或模板管理。</p>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>