<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_permission('manage_content');
require_login();

$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$status = $_POST['status'] ?? 'draft';
$categoryId = isset($_POST['category_id']) && $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
$tagIds = array_map('intval', $_POST['tags'] ?? []);
$format = $_POST['format'] ?? 'markdown';

if ($title === '') {
    header('Location: /admin/articles.php?error=title');
    exit;
}

$authorId = (int)($_SESSION['user_id'] ?? 0);
$articleId = create_article($title, $content, $categoryId, $authorId, $status);
if (!empty($tagIds)) {
    require_once __DIR__ . '/../../server/content.php';
    set_article_tags($articleId, $tagIds);
}
// 保存内容格式为文章元数据
set_article_meta($articleId, 'format', in_array($format, ['markdown','html'], true) ? $format : 'markdown');

header('Location: /admin/articles.php?ok=1');
exit;