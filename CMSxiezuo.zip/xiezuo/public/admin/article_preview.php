<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$id = (int)($_GET['id'] ?? 0);
$article = $id ? get_article($id) : null;
if (!$article) { header('Location: /admin/articles.php'); exit; }
// 根据文章格式进行安全渲染
$format = get_article_format($id);
if ($format === 'html') {
  $rendered = sanitize_html_basic($article['content']);
} else {
  $rendered = render_markdown_safe($article['content']);
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>预览草稿 · <?= htmlspecialchars($article['title']) ?></title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-3xl mx-auto p-6">
      <div class="flex items-center justify-between">
        <h1 class="text-2xl font-semibold"><?= htmlspecialchars($article['title']) ?></h1>
        <a href="/admin/articles.php" class="rounded-lg bg-slate-800 px-3 py-2">返回列表</a>
      </div>
      <p class="mt-2 text-sm text-slate-400">分类：<?= htmlspecialchars($article['category'] ?? '未分类') ?> · 状态：<?= htmlspecialchars($article['status']) ?></p>
      <article class="prose prose-invert mt-6">
        <?= $rendered ?>
      </article>
    </div>
  </body>
</html>