<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/pay.php';
require_login();
require_permission('manage_system');
$response = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $sample = [
    'notify_time' => date('Y-m-d H:i:s'),
    'notify_type' => 'trade_status_sync',
    'trade_status' => 'TRADE_SUCCESS',
    'out_trade_no' => 'TEST'.time(),
    'trade_no' => '2025TEST'.rand(1000,9999),
    'buyer_id' => '2088101117955611',
    'buyer_pay_amount' => '0.01',
  ];
  $payload = http_build_query($sample);
  $url = '/payments/alipay_callback.php';
  // 内部调用：直接写入数据库以模拟回调
  log_payment_notification('alipay', $payload, 'received');
  $response = '已写入模拟通知（不发起真实HTTP）。';
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>通知测试面板 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-3xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">回调通知测试面板（支付宝）</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>
      <form action="/admin/payment_notify_test.php" method="post" class="card space-y-3">
        <p class="text-sm text-slate-400">点击下方按钮模拟一条回调通知写入数据库。</p>
        <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">写入模拟通知</button>
      </form>
      <?php if ($response): ?>
        <div class="card text-sm text-emerald-400">结果：<?= htmlspecialchars($response) ?></div>
      <?php endif; ?>
      <div class="card">
        <h2 class="text-lg font-semibold">最近通知</h2>
        <div class="mt-3 overflow-x-auto">
          <table class="w-full text-sm">
            <thead><tr class="text-slate-400"><th class="text-left py-2">ID</th><th class="text-left py-2">网关</th><th class="text-left py-2">状态</th><th class="text-left py-2">时间</th><th class="text-left py-2">内容</th></tr></thead>
            <tbody>
              <?php $pdo = getPDO(); $rows = $pdo->query("SELECT * FROM payment_notifications ORDER BY id DESC LIMIT 20")->fetchAll(); foreach ($rows as $r): ?>
                <tr class="border-t border-slate-800">
                  <td class="py-2"><?= (int)$r['id'] ?></td>
                  <td class="py-2"><?= htmlspecialchars($r['gateway']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($r['status']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($r['created_at']) ?></td>
                  <td class="py-2 break-all text-slate-300"><pre class="whitespace-pre-wrap"><?= htmlspecialchars($r['payload']) ?></pre></td>
                </tr>
              <?php endforeach; if (empty($rows)): ?>
                <tr><td colspan="5" class="py-3 text-slate-400">暂无数据。</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }</style>
  </body>
</html>