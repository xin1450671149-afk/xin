<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_permission('manage_content');
require_login();

$id = (int)($_POST['id'] ?? 0);
$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$status = $_POST['status'] ?? 'draft';
$categoryId = isset($_POST['category_id']) && $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
$tagIds = array_map('intval', $_POST['tags'] ?? []);
$format = $_POST['format'] ?? 'markdown';

if (!$id || $title === '') {
    header('Location: /admin/articles.php?error=update');
    exit;
}

update_article($id, $title, $content, $categoryId, $status);
set_article_tags($id, $tagIds);
// 更新内容格式元数据
set_article_meta($id, 'format', in_array($format, ['markdown','html'], true) ? $format : 'markdown');
header('Location: /admin/articles.php?ok=1');
exit;