<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('view_analytics');
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>统计分析 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <script src="/assets/vendor/chart.umd.min.js"></script>
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-5xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">统计分析</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>

      <div class="card">
        <div class="flex items-center justify-between">
          <h2 class="text-lg font-semibold">文章趋势</h2>
          <select id="rangeA" class="rounded-md bg-slate-800 border border-slate-700 px-2 py-1 text-sm">
            <option value="7">最近 7 天</option>
            <option value="30" selected>最近 30 天</option>
            <option value="60">最近 60 天</option>
          </select>
        </div>
        <canvas id="chartArticles" class="mt-4"></canvas>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="card">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold">注册用户</h2>
            <select id="rangeU" class="rounded-md bg-slate-800 border border-slate-700 px-2 py-1 text-sm">
              <option value="7">最近 7 天</option>
              <option value="30" selected>最近 30 天</option>
              <option value="60">最近 60 天</option>
            </select>
          </div>
          <canvas id="chartUsers" class="mt-4"></canvas>
        </div>
        <div class="card">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold">评论量</h2>
            <select id="rangeC" class="rounded-md bg-slate-800 border border-slate-700 px-2 py-1 text-sm">
              <option value="7">最近 7 天</option>
              <option value="30" selected>最近 30 天</option>
              <option value="60">最近 60 天</option>
            </select>
          </div>
          <canvas id="chartComments" class="mt-4"></canvas>
        </div>
      </div>
    </div>
    <style>
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
    <script>
      async function fetchMetric(metric, days) {
        const res = await fetch(`/admin/api/analytics.php?metric=${metric}&days=${days}`);
        return res.json();
      }

      const chartCfg = (labels, datasetLabel, data, color) => ({
        type: 'line',
        data: { labels, datasets: [{ label: datasetLabel, data, borderColor: color, backgroundColor: color.replace('1)', '0.15)'), tension: 0.35, fill: true }] },
        options: { plugins: { legend: { labels: { color: '#cbd5e1' } } }, scales: { x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } }, y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } } } }
      });

      const ctxA = document.getElementById('chartArticles');
      const ctxU = document.getElementById('chartUsers');
      const ctxC = document.getElementById('chartComments');

      async function renderArticles(days) {
        const j = await fetchMetric('articles', days);
        const labels = j.data.published.map(x => x.date);
        const dataP = j.data.published.map(x => x.count);
        const dataD = j.data.draft.map(x => x.count);
        new Chart(ctxA, {
          type: 'line',
          data: {
            labels,
            datasets: [
              { label: '已发布', data: dataP, borderColor: 'rgba(34,211,238,1)', backgroundColor: 'rgba(34,211,238,0.15)', tension: 0.35, fill: true },
              { label: '草稿', data: dataD, borderColor: 'rgba(244,114,182,1)', backgroundColor: 'rgba(244,114,182,0.15)', tension: 0.35, fill: true },
            ]
          },
          options: { plugins: { legend: { labels: { color: '#cbd5e1' } } }, scales: { x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } }, y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.15)' } } } }
        });
      }

      async function renderUsers(days) {
        const j = await fetchMetric('users', days);
        const labels = j.data.map(x => x.date);
        const data = j.data.map(x => x.count);
        new Chart(ctxU, chartCfg(labels, '注册用户数', data, 'rgba(34,197,94,1)'));
      }

      async function renderComments(days) {
        const j = await fetchMetric('comments', days);
        const labels = j.data.map(x => x.date);
        const data = j.data.map(x => x.count);
        new Chart(ctxC, chartCfg(labels, '评论数', data, 'rgba(99,102,241,1)'));
      }

      const selA = document.getElementById('rangeA');
      const selU = document.getElementById('rangeU');
      const selC = document.getElementById('rangeC');
      selA.addEventListener('change', e => renderArticles(parseInt(e.target.value,10)));
      selU.addEventListener('change', e => renderUsers(parseInt(e.target.value,10)));
      selC.addEventListener('change', e => renderComments(parseInt(e.target.value,10)));
      renderArticles(parseInt(selA.value,10));
      renderUsers(parseInt(selU.value,10));
      renderComments(parseInt(selC.value,10));
    </script>
  </body>
</html>