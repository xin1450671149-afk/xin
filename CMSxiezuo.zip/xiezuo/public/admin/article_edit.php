<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$id = (int)($_GET['id'] ?? 0);
$article = $id ? get_article($id) : null;
if (!$article) { header('Location: /admin/articles.php'); exit; }
$categories = list_categories();
$tags = list_tags();
$selectedTags = array_map(fn($t) => (int)$t['id'], get_article_tags($id));
$format = get_article_format($id);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>编辑文章 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-4xl mx-auto p-6">
      <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">编辑文章</h1>
        <a href="/admin/articles.php" class="rounded-lg bg-slate-800 px-3 py-2">返回列表</a>
      </div>

      <form action="/admin/article_update.php" method="post" class="card space-y-3">
        <input type="hidden" name="id" value="<?= (int)$article['id'] ?>" />
        <div>
          <label class="block text-sm">标题</label>
          <input name="title" value="<?= htmlspecialchars($article['title']) ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">分类</label>
          <select name="category_id" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
            <option value="">未分类</option>
            <?php foreach ($categories as $c): $sel = ($article['category_id'] ?? null) == $c['id']; ?>
              <option value="<?= (int)$c['id'] ?>" <?= $sel ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-sm">内容</label>
          <textarea name="content" rows="10" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><?= htmlspecialchars($article['content']) ?></textarea>
        </div>
        <div>
          <label class="block text-sm">内容格式</label>
          <div class="inline-flex items-center gap-4 mt-1 text-sm">
            <label class="inline-flex items-center gap-2"><input type="radio" name="format" value="markdown" <?= $format==='html'?'':'checked'; ?>> Markdown</label>
            <label class="inline-flex items-center gap-2"><input type="radio" name="format" value="html" <?= $format==='html'?'checked':''; ?>> HTML</label>
          </div>
        </div>
        <div>
          <label class="block text-sm">标签</label>
          <div class="grid grid-cols-2 gap-2">
            <?php foreach ($tags as $t): $checked = in_array((int)$t['id'], $selectedTags, true); ?>
              <label class="inline-flex items-center gap-2 rounded-lg bg-slate-800/40 border border-slate-700 px-3 py-2">
                <input type="checkbox" name="tags[]" value="<?= (int)$t['id'] ?>" class="rounded" <?= $checked ? 'checked' : '' ?> />
                <span><?= htmlspecialchars($t['name']) ?></span>
              </label>
            <?php endforeach; ?>
            <?php if (empty($tags)): ?>
              <p class="text-slate-400 text-sm">暂无标签，可先到“标签管理”创建。</p>
            <?php endif; ?>
          </div>
        </div>
        <div>
          <label class="block text-sm">状态</label>
          <select name="status" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
            <option value="draft" <?= $article['status']==='draft'?'selected':'' ?>>草稿</option>
            <option value="published" <?= $article['status']==='published'?'selected':'' ?>>已发布</option>
          </select>
        </div>
        <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
      </form>
    </div>
    <style>
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
  </body>
</html>