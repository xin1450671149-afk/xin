<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/recharge.php';
require_login();
require_permission('manage_system');

$msg = null; $error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $out_trade_no = trim($_POST['out_trade_no'] ?? '');
  if ($action && $out_trade_no) {
    $order = get_recharge_by_out_trade_no($out_trade_no);
    if (!$order) { $error = '订单不存在：'.$out_trade_no; }
    else {
      if ($action === 'mark_paid') {
        if (mark_recharge_paid($out_trade_no, $order['trade_no'] ?? '', (int)($order['notification_id'] ?? 0))) {
          $msg = '已标记为支付成功：'.$out_trade_no;
        } else { $error = '标记失败'; }
      } elseif ($action === 'mark_failed') {
        if (mark_recharge_failed($out_trade_no, (int)($order['notification_id'] ?? 0))) {
          $msg = '已标记为失败：'.$out_trade_no;
        } else { $error = '标记失败'; }
      }
    }
  }
}
$rows = list_recharge_orders(100);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>充值订单 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">充值订单</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">订单列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($msg): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

          <section class="xl:col-span-3 card">
            <div class="overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="text-slate-400">
                    <th class="text-left py-2">ID</th>
                    <th class="text-left py-2">用户</th>
                    <th class="text-left py-2">订单号</th>
                    <th class="text-left py-2">金额</th>
                    <th class="text-left py-2">网关</th>
                    <th class="text-left py-2">状态</th>
                    <th class="text-left py-2">创建时间</th>
                    <th class="text-left py-2">支付时间</th>
                    <th class="text-left py-2">操作</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($rows as $r): ?>
                    <tr class="border-t border-slate-800">
                      <td class="py-2"><?php echo (int)$r['id']; ?></td>
                      <td class="py-2"><?php echo htmlspecialchars($r['username'] ?? '—'); ?></td>
                      <td class="py-2 font-mono"><?php echo htmlspecialchars($r['out_trade_no']); ?></td>
                      <td class="py-2"><?php echo number_format((float)$r['amount'], 2).' '.htmlspecialchars($r['currency']); ?></td>
                      <td class="py-2"><?php echo htmlspecialchars($r['gateway']); ?></td>
                      <td class="py-2"><?php echo htmlspecialchars($r['status']); ?></td>
                      <td class="py-2"><?php echo htmlspecialchars($r['created_at']); ?></td>
                      <td class="py-2"><?php echo htmlspecialchars($r['paid_at'] ?? ''); ?></td>
                      <td class="py-2">
                        <form method="post" class="inline-flex items-center gap-2">
                          <input type="hidden" name="out_trade_no" value="<?php echo htmlspecialchars($r['out_trade_no']); ?>" />
                          <button name="action" value="mark_paid" class="rounded bg-emerald-600 px-2 py-1 text-xs">标记成功</button>
                          <button name="action" value="mark_failed" class="rounded bg-rose-600 px-2 py-1 text-xs">标记失败</button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; if (empty($rows)): ?>
                    <tr><td colspan="9" class="py-3 text-slate-400">暂无订单。</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </main>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    .card-notice-ok { border-radius:1rem; background-color:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.4); padding:1rem; }
    .card-notice-error { border-radius:1rem; background-color:rgba(244,63,94,0.15); border:1px solid rgba(244,63,94,0.4); padding:1rem; }
    .nav-item { display:block; padding:0.5rem 0.75rem; border-radius:0.75rem; color:#cbd5e1; }
    .nav-item:hover { background:#0f172a; color:#fff; }
    </style>
  </body>
</html>