<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/doubao_config.php';
require_login();
require_permission('manage_system');

$notice = null; $warn = null; $test_result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'save_image') {
    save_doubao_config('image', [
      'enabled' => ($_POST['image_enabled'] ?? '') === 'on',
      'api_key' => $_POST['image_api_key'] ?? '',
      'model_id' => $_POST['image_model_id'] ?? '',
      'endpoint_url' => $_POST['image_endpoint'] ?? '',
      'points_per_unit' => (int)($_POST['image_points'] ?? 100),
      'pricing_unit' => 'per_image',
    ]);
    $notice = '图片（文生图/图生图）配置已保存。';
  } elseif ($action === 'test_image') {
    $test_result = test_doubao_image_api();
  } elseif ($action === 'save_video') {
    save_doubao_config('video', [
      'enabled' => ($_POST['video_enabled'] ?? '') === 'on',
      'api_key' => $_POST['video_api_key'] ?? '',
      'model_id' => $_POST['video_model_id'] ?? '',
      'endpoint_url' => $_POST['video_endpoint'] ?? '',
      'points_per_unit' => (int)($_POST['video_points'] ?? 100),
      'pricing_unit' => 'per_video',
    ]);
    $notice = '视频（文生视频/图生视频）配置已保存。';
  } elseif ($action === 'test_video') {
    $test_result = test_doubao_video_api();
  }
}

$imgCfg = get_doubao_config('image');
$vidCfg = get_doubao_config('video');
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>豆包模型配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-6xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">豆包模型配置</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>

      <?php if ($notice): ?><div class="card-notice-ok"><?php echo htmlspecialchars($notice); ?></div><?php endif; ?>
      <?php if ($warn): ?><div class="card-notice-warn"><?php echo htmlspecialchars($warn); ?></div><?php endif; ?>
      <?php if ($test_result): ?>
        <div class="card">
          <div class="text-sm">接口测试结果：
            <?php if (!empty($test_result['ok'])): ?>
              <span class="text-green-400">OK</span>
            <?php else: ?>
              <span class="text-red-400">FAILED</span>
            <?php endif; ?> · 状态码：<?php echo (int)($test_result['status'] ?? 0); ?>
          </div>
          <?php if (!empty($test_result['error'])): ?><div class="mt-2 text-slate-300 text-xs">错误：<?php echo htmlspecialchars((string)$test_result['error']); ?></div><?php endif; ?>
          <?php if (!empty($test_result['sample'])): ?><pre class="mt-2 text-xs whitespace-pre-wrap text-slate-300"><?php echo htmlspecialchars((string)$test_result['sample']); ?></pre><?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- 左侧：文生图/图生图 -->
        <div class="card space-y-3">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold">图片：文生图 / 图生图</h2>
            <a class="text-cyan-400 text-sm" href="https://www.volcengine.com/docs/82379/1541523" target="_blank" rel="noreferrer">官方文档</a>
          </div>
          <form method="post" class="space-y-3">
            <input type="hidden" name="action" value="save_image" />
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="image_enabled" <?php echo !empty($imgCfg['enabled']) ? 'checked' : ''; ?> /> 功能开启</label>
            <div>
              <label class="block text-sm">秘钥</label>
              <input name="image_api_key" value="<?php echo htmlspecialchars((string)($imgCfg['api_key'] ?? '')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div>
              <label class="block text-sm">模型标识</label>
              <input name="image_model_id" value="<?php echo htmlspecialchars((string)($imgCfg['model_id'] ?? 'doubao-seedream-4-0-250828')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div>
              <label class="block text-sm">官方接口路径</label>
              <input name="image_endpoint" value="<?php echo htmlspecialchars((string)($imgCfg['endpoint_url'] ?? 'https://ark.cn-beijing.volces.com/api/v3/images/generations')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-sm">积分定价</label>
                <input type="number" min="1" name="image_points" value="<?php echo (int)($imgCfg['points_per_unit'] ?? 100); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">计价逻辑</label>
                <input value="一张一次" disabled class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
              <button type="button" onclick="submitTest('image')" class="rounded-lg bg-slate-800 px-4 py-2.5">接口测试</button>
            </div>
          </form>
        </div>

        <!-- 右侧：文生视频/图生视频 -->
        <div class="card space-y-3">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold">视频：文生视频 / 图生视频</h2>
            <a class="text-cyan-400 text-sm" href="https://www.volcengine.com/docs/82379/1520757" target="_blank" rel="noreferrer">官方文档</a>
          </div>
          <form method="post" class="space-y-3">
            <input type="hidden" name="action" value="save_video" />
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="video_enabled" <?php echo !empty($vidCfg['enabled']) ? 'checked' : ''; ?> /> 功能开启</label>
            <div>
              <label class="block text-sm">秘钥</label>
              <input name="video_api_key" value="<?php echo htmlspecialchars((string)($vidCfg['api_key'] ?? '')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div>
              <label class="block text-sm">模型标识</label>
              <input name="video_model_id" value="<?php echo htmlspecialchars((string)($vidCfg['model_id'] ?? 'doubao-seedance-1-0-pro-250528')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div>
              <label class="block text-sm">官方接口路径</label>
              <input name="video_endpoint" value="<?php echo htmlspecialchars((string)($vidCfg['endpoint_url'] ?? 'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks')); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-sm">积分定价</label>
                <input type="number" min="1" name="video_points" value="<?php echo (int)($vidCfg['points_per_unit'] ?? 100); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">计价逻辑</label>
                <input value="按次数：1 次 = 100 积分" disabled class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
              <button type="button" onclick="submitTest('video')" class="rounded-lg bg-slate-800 px-4 py-2.5">接口测试</button>
            </div>
          </form>
        </div>
      </div>

      <div class="card text-sm text-slate-300">
        <p>说明：</p>
        <ul class="list-disc pl-5 mt-2 space-y-1">
          <li>“接口测试”会向官方接口发送最小化请求，可能产生少量调用费用，请谨慎操作。</li>
          <li>图片模型默认标识：<code>doubao-seedream-4-0-250828</code>；视频模型默认标识：<code>doubao-seedance-1-0-pro-250528</code>。</li>
          <li>文档参考：图片 API（Seedream 4.0）与视频生成 API（Seedance）。</li>
        </ul>
      </div>
    </div>
    <style>
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
      .card-notice-ok { border-radius:.75rem; background-color:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.4); padding:.75rem; }
      .card-notice-warn { border-radius:.75rem; background-color:rgba(234,179,8,0.1); border:1px solid rgba(234,179,8,0.4); padding:.75rem; }
    </style>
    <script>
      function submitTest(which){
        const f = document.createElement('form');
        f.method = 'post';
        f.action = '/admin/doubao_config.php';
        const s = document.createElement('input');
        s.type = 'hidden';
        s.name = 'action';
        s.value = which === 'image' ? 'test_image' : 'test_video';
        f.appendChild(s);
        document.body.appendChild(f);
        f.submit();
      }
    </script>
  </body>
</html>