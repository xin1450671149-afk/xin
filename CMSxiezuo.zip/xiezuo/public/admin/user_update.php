<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_users');

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) { header('Location: /admin/users.php?error=bad_id'); exit; }

$email = trim($_POST['email'] ?? '');
$newPassword = trim($_POST['new_password'] ?? '');
$pointsDelta = (int)($_POST['points_delta'] ?? 0);
$level = trim($_POST['membership_level'] ?? '');

try {
  // 邮箱更新（允许空值）
  update_user_email($id, $email !== '' ? $email : null);
  // 密码修改（仅当提供时）
  if ($newPassword !== '') { update_user_password($id, $newPassword); }
  // 积分增减（允许负数，最小归零）
  if ($pointsDelta !== 0) { adjust_user_points($id, $pointsDelta); }
  // 会员等级设置（当提供时）
  if ($level !== '') { set_user_membership($id, $level); }
  header('Location: /admin/users.php?ok=1');
} catch (Throwable $e) {
  header('Location: /admin/users.php?error=' . urlencode($e->getMessage()));
}
exit;
?>