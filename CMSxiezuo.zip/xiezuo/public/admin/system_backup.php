<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$backupDir = __DIR__ . '/../../server/storage/backups';
if (!is_dir($backupDir)) { @mkdir($backupDir, 0777, true); }

$msg = null;
if (isset($_GET['action']) && $_GET['action'] === 'create') {
  $file = $backupDir . '/backup_' . date('Ymd_His') . '.txt';
  $content = "这是一个示例备份文件，时间：" . date('c') . "\n";
  file_put_contents($file, $content);
  $msg = '备份已创建：' . basename($file);
}

$files = [];
if (is_dir($backupDir)) {
  foreach (glob($backupDir . '/*') as $path) {
    $files[] = [
      'name' => basename($path),
      'size' => filesize($path),
      'mtime' => filemtime($path),
    ];
  }
  usort($files, fn($a,$b) => $b['mtime'] <=> $a['mtime']);
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>备份管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">备份管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">数据备份</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($msg): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

          <section class="card">
            <h3 class="text-lg font-semibold">操作</h3>
            <div class="mt-3 flex items-center gap-3">
              <a href="/admin/system_backup.php?action=create" class="rounded-lg bg-emerald-600 px-4 py-2.5">立即备份</a>
            </div>
            <p class="mt-2 text-sm text-slate-300">创建一个示例备份文件到 <code>server/storage/backups</code>。</p>
          </section>

          <section class="xl:col-span-2 card">
            <h3 class="text-lg font-semibold">备份列表</h3>
            <div class="mt-3 overflow-x-auto">
              <table class="w-full text-sm">
                <thead>
                  <tr class="text-slate-400">
                    <th class="text-left p-2">文件名</th>
                    <th class="text-left p-2">大小</th>
                    <th class="text-left p-2">时间</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($files as $f): ?>
                    <tr class="border-t border-slate-800">
                      <td class="p-2"><?php echo htmlspecialchars($f['name']); ?></td>
                      <td class="p-2"><?php echo number_format($f['size']); ?> B</td>
                      <td class="p-2"><?php echo date('Y-m-d H:i:s', $f['mtime']); ?></td>
                    </tr>
                  <?php endforeach; ?>
                  <?php if (empty($files)): ?>
                    <tr><td class="p-3 text-slate-400" colspan="3">暂无备份文件</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>