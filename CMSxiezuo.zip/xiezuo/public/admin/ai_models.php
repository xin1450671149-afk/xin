<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $provider = $_POST['provider'] ?? 'one-api';
  $api_base = trim($_POST['api_base'] ?? '');
  $api_key = trim($_POST['api_key'] ?? '');
  $model = trim($_POST['model'] ?? '');
  if ($name && $api_base && $api_key && $model) {
    create_ai_model($name, $provider, $api_base, $api_key, $model, null, 'active');
    header('Location: /admin/ai_models.php?ok=1');
    exit;
  } else {
    header('Location: /admin/ai_models.php?error=invalid');
    exit;
  }
}
$models = list_ai_models();
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>AI 模型配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-5xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">AI 模型配置</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>

      <form action="/admin/ai_models.php" method="post" class="card grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm">名称</label>
          <input name="name" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">Provider</label>
          <select name="provider" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><option value="one-api">one-api</option></select>
        </div>
        <div>
          <label class="block text-sm">API Base</label>
          <input name="api_base" placeholder="https://one-api.example.com" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">API Key</label>
          <input name="api_key" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">模型名</label>
          <input name="model" placeholder="gpt-4o-mini" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div class="md:col-span-2">
          <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存模型</button>
        </div>
      </form>

      <div class="card">
        <h2 class="text-lg font-semibold">模型列表</h2>
        <div class="mt-3 overflow-x-auto">
          <table class="w-full text-sm">
            <thead><tr class="text-slate-400"><th class="text-left py-2">名称</th><th class="text-left py-2">提供方</th><th class="text-left py-2">模型</th><th class="text-left py-2">API Base</th><th class="text-left py-2">状态</th><th class="text-left py-2">操作</th></tr></thead>
            <tbody>
              <?php foreach ($models as $m): ?>
                <tr class="border-t border-slate-800">
                  <td class="py-2"><?= htmlspecialchars($m['name']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($m['provider']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($m['model']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($m['api_base']) ?></td>
                  <td class="py-2"><?= htmlspecialchars($m['status']) ?></td>
                  <td class="py-2">
                    <a class="text-cyan-400" href="/admin/ai_test.php?id=<?= (int)$m['id'] ?>">接口测试</a>
                    <span class="mx-2 text-slate-600">|</span>
                    <button
                      class="text-cyan-400"
                      data-id="<?= (int)$m['id'] ?>"
                      data-name="<?= htmlspecialchars($m['name']) ?>"
                      data-provider="<?= htmlspecialchars($m['provider']) ?>"
                      data-api_base="<?= htmlspecialchars($m['api_base']) ?>"
                      data-api_key="<?= htmlspecialchars($m['api_key']) ?>"
                      data-model="<?= htmlspecialchars($m['model']) ?>"
                      data-status="<?= htmlspecialchars($m['status']) ?>"
                      onclick="openEdit(this)"
                    >编辑</button>
                    <span class="mx-2 text-slate-600">|</span>
                    <a class="text-rose-400" href="/admin/ai_model_delete.php?id=<?= (int)$m['id'] ?>" onclick="return confirm('确认删除该模型？');">删除</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (empty($models)): ?>
                <tr><td colspan="6" class="py-3 text-slate-400">暂无模型，请上方添加。</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      
      <!-- 编辑模型弹窗 -->
      <div id="editModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center">
        <div class="card w-[640px] max-w-full">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-lg font-semibold">编辑模型</h3>
            <button class="rounded bg-slate-800 px-2 py-1" onclick="closeEdit()">关闭</button>
          </div>
          <form id="editForm" method="post" action="/admin/ai_model_update.php">
            <input type="hidden" name="id" id="edit_id" />
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-sm">名称</label>
                <input name="name" id="edit_name" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">Provider</label>
                <select name="provider" id="edit_provider" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                  <option value="one-api">one-api</option>
                </select>
              </div>
              <div>
                <label class="block text-sm">API Base</label>
                <input name="api_base" id="edit_api_base" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">API Key</label>
                <input name="api_key" id="edit_api_key" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">模型名</label>
                <input name="model" id="edit_model" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">状态</label>
                <select name="status" id="edit_status" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                  <option value="active">active</option>
                  <option value="inactive">inactive</option>
                </select>
              </div>
              <div class="md:col-span-2">
                <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存修改</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }</style>
    <script>
      function openEdit(btn) {
        const d = btn.dataset;
        document.getElementById('edit_id').value = d.id || '';
        document.getElementById('edit_name').value = d.name || '';
        document.getElementById('edit_provider').value = d.provider || 'one-api';
        document.getElementById('edit_api_base').value = d.api_base || '';
        document.getElementById('edit_api_key').value = d.api_key || '';
        document.getElementById('edit_model').value = d.model || '';
        document.getElementById('edit_status').value = d.status || 'active';
        document.getElementById('editModal').classList.remove('hidden');
        document.getElementById('editModal').classList.add('flex');
      }
      function closeEdit() {
        document.getElementById('editModal').classList.add('hidden');
        document.getElementById('editModal').classList.remove('flex');
      }
    </script>
  </body>
</html>