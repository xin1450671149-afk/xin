<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_permissions');

$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
if ($name === '') {
    header('Location: /admin/permissions.php?msg=' . urlencode('权限名称不能为空'));
    exit;
}

create_permission($name, $description !== '' ? $description : null);
header('Location: /admin/permissions.php?msg=' . urlencode('权限创建成功'));
exit;
?>