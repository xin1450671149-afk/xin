<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$id = (int)($_GET['id'] ?? 0);
$c = $id ? get_comment($id) : null;
if (!$c) { header('Location: /admin/comments.php'); exit; }
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>评论详情 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-3xl mx-auto p-6">
      <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">评论详情</h1>
        <a href="/admin/comments.php" class="rounded-lg bg-slate-800 px-3 py-2">返回列表</a>
      </div>

      <div class="card space-y-3">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-slate-400">作者</p>
            <p class="text-base font-medium"><?= htmlspecialchars($c['author']) ?></p>
          </div>
          <div>
            <p class="text-sm text-slate-400">文章</p>
            <p class="text-base font-medium text-slate-300"><?= htmlspecialchars($c['article_title']) ?></p>
          </div>
        </div>
        <div>
          <p class="text-sm text-slate-400">内容</p>
          <div class="rounded-lg bg-slate-800/60 border border-slate-700 p-3 text-slate-200 whitespace-pre-wrap"><?= htmlspecialchars($c['body']) ?></div>
        </div>
        <div>
          <p class="text-sm text-slate-400">当前状态</p>
          <p class="text-sm">
            <?php if ($c['status']==='approved'): ?><span class="rounded bg-emerald-500/20 text-emerald-400 px-2 py-0.5">已通过</span><?php endif; ?>
            <?php if ($c['status']==='pending'): ?><span class="rounded bg-amber-500/20 text-amber-400 px-2 py-0.5">待审核</span><?php endif; ?>
            <?php if ($c['status']==='spam'): ?><span class="rounded bg-rose-500/20 text-rose-400 px-2 py-0.5">垃圾</span><?php endif; ?>
          </p>
        </div>

        <div class="flex items-center gap-2">
          <form method="post" action="/admin/comment_update_status.php">
            <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
            <input type="hidden" name="status" value="approved" />
            <button class="rounded bg-emerald-600/80 px-3 py-1.5">通过</button>
          </form>
          <form method="post" action="/admin/comment_update_status.php">
            <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
            <input type="hidden" name="status" value="pending" />
            <button class="rounded bg-amber-600/80 px-3 py-1.5">待审</button>
          </form>
          <form method="post" action="/admin/comment_update_status.php" onsubmit="return confirm('确认标记为垃圾？');">
            <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
            <input type="hidden" name="status" value="spam" />
            <button class="rounded bg-rose-600/80 px-3 py-1.5">垃圾</button>
          </form>
          <a href="/admin/comment_delete.php?id=<?= (int)$c['id'] ?>" class="rounded bg-slate-800 px-3 py-1.5" onclick="return confirm('确认删除该评论？');">删除</a>
        </div>
      </div>
    </div>
    <style>
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
  </body>
</html>