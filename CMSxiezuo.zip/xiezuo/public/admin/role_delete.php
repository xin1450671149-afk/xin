<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_roles');

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    delete_role($id);
}
header('Location: /admin/roles.php?msg=' . urlencode('角色已删除'));
exit;
?>