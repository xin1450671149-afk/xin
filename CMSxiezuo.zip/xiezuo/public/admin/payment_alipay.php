<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/pay.php';
require_login();
require_permission('manage_system');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $cfg = [
    'app_id' => trim($_POST['app_id'] ?? ''),
    'private_key' => trim($_POST['private_key'] ?? ''),
    'alipay_public_key' => trim($_POST['alipay_public_key'] ?? ''),
    'notify_url' => trim($_POST['notify_url'] ?? ''),
    'return_url' => trim($_POST['return_url'] ?? ''),
    'sandbox' => isset($_POST['sandbox']) ? 1 : 0,
  ];
  if ($cfg['app_id'] && $cfg['private_key'] && $cfg['alipay_public_key'] && $cfg['notify_url'] && $cfg['return_url']) {
    save_alipay_config($cfg);
    header('Location: /admin/payment_alipay.php?ok=1');
    exit;
  } else {
    header('Location: /admin/payment_alipay.php?error=invalid');
    exit;
  }
}
$cur = get_alipay_config();
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>支付宝配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-4xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">支付宝配置</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>
      <form action="/admin/payment_alipay.php" method="post" class="card grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm">App ID</label>
          <input name="app_id" value="<?= htmlspecialchars($cur['app_id'] ?? '') ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">API Base（回调展示用）</label>
          <input value="<?= htmlspecialchars(($cur['notify_url'] ?? '')) ?>" disabled class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div class="md:col-span-2">
          <label class="block text-sm">私钥（PKCS8）</label>
          <textarea name="private_key" rows="4" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><?= htmlspecialchars($cur['private_key'] ?? '') ?></textarea>
        </div>
        <div class="md:col-span-2">
          <label class="block text-sm">支付宝公钥</label>
          <textarea name="alipay_public_key" rows="3" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><?= htmlspecialchars($cur['alipay_public_key'] ?? '') ?></textarea>
        </div>
        <div>
          <label class="block text-sm">Notify URL</label>
          <input name="notify_url" value="<?= htmlspecialchars($cur['notify_url'] ?? '') ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <div>
          <label class="block text-sm">Return URL</label>
          <input name="return_url" value="<?= htmlspecialchars($cur['return_url'] ?? '') ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <label class="inline-flex items-center gap-2"><input type="checkbox" name="sandbox" <?= ($cur['sandbox'] ?? 1) ? 'checked' : '' ?>> 沙箱模式</label>
        <div class="md:col-span-2">
          <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存配置</button>
        </div>
      </form>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }</style>
  </body>
</html>