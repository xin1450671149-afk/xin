<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_permissions');

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    delete_permission($id);
}
header('Location: /admin/permissions.php?msg=' . urlencode('权限已删除'));
exit;
?>