<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$total = articles_count($q ?: null);
$articles = list_articles($page, $perPage, $q ?: null);
$categories = list_categories();
$tags = list_tags();
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>文章管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">文章管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">文章列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <form class="xl:col-span-3 mb-2 flex items-center gap-2" method="get" action="/admin/articles.php" aria-label="搜索文章">
            <input type="search" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="搜索标题..." class="flex-1 rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            <button class="rounded-lg bg-slate-800 px-3 py-2">搜索</button>
          </form>
          <section class="xl:col-span-2 card">
            <table class="w-full text-sm">
              <thead>
                <tr class="text-slate-400">
                  <th class="text-left p-2">标题</th>
                  <th class="text-left p-2">分类</th>
                  <th class="text-left p-2">状态</th>
                  <th class="text-left p-2">创建时间</th>
                  <th class="text-left p-2">操作</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($articles as $a): ?>
                <tr class="border-t border-slate-800">
                  <td class="p-2"><?= htmlspecialchars($a['title']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($a['category'] ?? '未分类') ?></td>
                  <td class="p-2"><?= htmlspecialchars($a['status']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($a['created_at']) ?></td>
                  <td class="p-2">
                    <a href="/admin/article_edit.php?id=<?= (int)$a['id'] ?>" class="text-cyan-400">编辑</a>
                    <span class="mx-2 text-slate-600">|</span>
                    <a href="/admin/article_delete.php?id=<?= (int)$a['id'] ?>" class="text-rose-400" onclick="return confirm('确认删除该文章？');">删除</a>
                    <?php if ($a['status'] === 'draft'): ?>
                      <span class="mx-2 text-slate-600">|</span>
                      <a href="/admin/article_preview.php?id=<?= (int)$a['id'] ?>" class="text-amber-400">预览</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($articles)): ?>
                <tr><td class="p-3 text-slate-400" colspan="5">暂无文章</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
            <?php $pages = max(1, (int)ceil($total / $perPage)); if ($pages > 1): ?>
              <nav class="mt-4 flex items-center gap-2" aria-label="分页导航">
                <?php for ($i = 1; $i <= $pages; $i++): $active = $i === $page; ?>
                  <a class="rounded-md border border-slate-700 px-3 py-1 <?= $active ? 'bg-slate-800 text-white' : 'text-slate-300' ?>" href="/admin/articles.php?page=<?= $i ?>&q=<?= urlencode($q) ?>">
                    <?= $i ?>
                  </a>
                <?php endfor; ?>
              </nav>
            <?php endif; ?>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">新增文章</h3>
            <form action="/admin/article_create.php" method="post" class="mt-4 space-y-3">
              <div>
                <label class="block text-sm">标题</label>
                <input name="title" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">分类</label>
                <select name="category_id" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                  <option value="">未分类</option>
                  <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div>
                <label class="block text-sm">内容</label>
                <textarea name="content" rows="6" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" placeholder="支持 Markdown/HTML"></textarea>
              </div>
              <div>
                <label class="block text-sm">内容格式</label>
                <div class="inline-flex items-center gap-4 mt-1 text-sm">
                  <label class="inline-flex items-center gap-2"><input type="radio" name="format" value="markdown" checked> Markdown</label>
                  <label class="inline-flex items-center gap-2"><input type="radio" name="format" value="html"> HTML</label>
                </div>
              </div>
              <div>
                <label class="block text-sm">标签</label>
                <div class="grid grid-cols-2 gap-2">
                  <?php foreach ($tags as $t): ?>
                    <label class="inline-flex items-center gap-2 rounded-lg bg-slate-800/40 border border-slate-700 px-3 py-2">
                      <input type="checkbox" name="tags[]" value="<?= (int)$t['id'] ?>" class="rounded" />
                      <span><?= htmlspecialchars($t['name']) ?></span>
                    </label>
                  <?php endforeach; ?>
                  <?php if (empty($tags)): ?>
                    <p class="text-slate-400 text-sm">暂无标签，可先到“标签管理”创建。</p>
                  <?php endif; ?>
                </div>
              </div>
              <div>
                <label class="block text-sm">状态</label>
                <select name="status" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                  <option value="draft">草稿</option>
                  <option value="published">已发布</option>
                </select>
              </div>
              <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">创建</button>
            </form>
          </section>
        </div>
      </main>
    </div>
    <style>
      .nav-item { display:block; margin-top:0.25rem; padding:0.5rem 0.75rem; border-radius:0.5rem; color:#cbd5e1; }
      .nav-item:hover { background-color: rgba(30,41,59,0.7); color:#fff; }
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
  </body>
</html>