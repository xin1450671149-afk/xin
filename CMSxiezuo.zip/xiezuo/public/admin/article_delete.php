<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$id = (int)($_GET['id'] ?? 0);
if ($id) { delete_article($id); }
header('Location: /admin/articles.php?ok=1');
exit;