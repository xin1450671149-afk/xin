<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_permissions');

$id = (int)($_GET['id'] ?? 0);
$perm = $id ? get_permission($id) : null;
if (!$perm) {
    header('Location: /admin/permissions.php?msg=' . urlencode('权限不存在'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑权限</title>
    <link rel="stylesheet" href="/assets/admin.css">
</head>
<body>
<header>
    <h1>编辑权限：<?php echo htmlspecialchars($perm['name']); ?></h1>
    <nav><a href="/admin/permissions.php">返回权限列表</a></nav>
</header>

<section>
    <form method="post" action="/admin/permission_update.php?id=<?php echo (int)$perm['id']; ?>">
        <label>名称：<input type="text" name="name" value="<?php echo htmlspecialchars($perm['name']); ?>" required></label>
        <label>描述：<input type="text" name="description" value="<?php echo htmlspecialchars($perm['description'] ?? ''); ?>"></label>
        <button type="submit">保存</button>
    </form>
    <p>
        <a href="/admin/permission_delete.php?id=<?php echo (int)$perm['id']; ?>" onclick="return confirm('删除该权限？');">删除权限</a>
    </p>
</section>

</body>
</html>