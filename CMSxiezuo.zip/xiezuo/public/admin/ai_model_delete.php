<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  header('Location: /admin/ai_models.php?error=bad_request');
  exit;
}

try {
  delete_ai_model($id);
  header('Location: /admin/ai_models.php?ok=deleted');
  exit;
} catch (Throwable $e) {
  header('Location: /admin/ai_models.php?error=' . urlencode($e->getMessage()));
  exit;
}