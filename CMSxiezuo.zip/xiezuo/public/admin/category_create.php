<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$name = trim($_POST['name'] ?? '');
$slug = trim($_POST['slug'] ?? '');
if ($name === '') { header('Location: /admin/categories.php?error=name'); exit; }

create_category($name, $slug !== '' ? $slug : null);
header('Location: /admin/categories.php?ok=1');
exit;