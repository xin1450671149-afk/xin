<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$id = (int)($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$slug = trim($_POST['slug'] ?? '');
if (!$id || $name === '') { header('Location: /admin/categories.php?error=update'); exit; }

update_category($id, $name, $slug !== '' ? $slug : null);
header('Location: /admin/categories.php?ok=1');
exit;