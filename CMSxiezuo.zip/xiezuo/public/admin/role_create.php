<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_roles');

$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
if ($name === '') {
    header('Location: /admin/roles.php?msg=' . urlencode('角色名称不能为空'));
    exit;
}

create_role($name, $description !== '' ? $description : null);
header('Location: /admin/roles.php?msg=' . urlencode('角色创建成功'));
exit;
?>