<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');

$id = (int)($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
$provider = trim($_POST['provider'] ?? 'one-api');
$api_base = trim($_POST['api_base'] ?? '');
$api_key = trim($_POST['api_key'] ?? '');
$model = trim($_POST['model'] ?? '');
$status = trim($_POST['status'] ?? 'active');

if ($id <= 0 || $name === '' || $api_base === '' || $api_key === '' || $model === '') {
  header('Location: /admin/ai_models.php?error=bad_request');
  exit;
}

$fields = [
  'name' => $name,
  'provider' => $provider,
  'api_base' => $api_base,
  'api_key' => $api_key,
  'model' => $model,
  'status' => $status ?: 'active'
];

try {
  update_ai_model($id, $fields);
  header('Location: /admin/ai_models.php?ok=updated');
  exit;
} catch (Throwable $e) {
  header('Location: /admin/ai_models.php?error=' . urlencode($e->getMessage()));
  exit;
}