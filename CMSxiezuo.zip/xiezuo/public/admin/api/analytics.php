<?php
require_once __DIR__ . '/../../../server/auth.php';
require_once __DIR__ . '/../../../server/analytics.php';
require_login();
require_permission('view_analytics');

header('Content-Type: application/json; charset=utf-8');
$metric = $_GET['metric'] ?? 'articles';
$days = max(1, min(90, (int)($_GET['days'] ?? 30)));

try {
  switch ($metric) {
    case 'articles':
      echo json_encode(['ok' => true, 'data' => get_article_stats($days)]);
      break;
    case 'users':
      echo json_encode(['ok' => true, 'data' => get_user_stats($days)]);
      break;
    case 'comments':
      echo json_encode(['ok' => true, 'data' => get_comment_stats($days)]);
      break;
    default:
      http_response_code(400);
      echo json_encode(['ok' => false, 'error' => 'unknown_metric']);
  }
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}