<?php
require_once __DIR__ . '/../../../server/auth.php';
require_login();
require_permission('manage_system');

$u = isset($_GET['u']) ? trim($_GET['u']) : '';
if ($u === '' || !preg_match('/^https?:\/\//i', $u)) {
  http_response_code(400);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'invalid_url']);
  exit;
}

// 代理获取外部图片，避免跨域或防盗链导致浏览器无法直链显示
$ch = curl_init($u);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_TIMEOUT => 20,
  CURLOPT_HTTPHEADER => [
    'Accept: image/*,application/octet-stream',
    'User-Agent: Mozilla/5.0 (Proxy Image Fetch)'
  ],
]);
$body = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$err = curl_error($ch);
curl_close($ch);

if ($err || $code < 200 || $code >= 300 || $body === false) {
  http_response_code(502);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'fetch_failed', 'status' => $code, 'message' => $err]);
  exit;
}

if (!$ctype) { $ctype = 'image/png'; }
header('Content-Type: '.$ctype);
header('Cache-Control: private, max-age=60');
echo $body;
?>