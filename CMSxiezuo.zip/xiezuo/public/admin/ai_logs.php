<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');
// 批量删除处理
$notice = null; $warn = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'bulk_delete') {
  $ids = array_map('intval', ($_POST['ids'] ?? []));
  $ids = array_values(array_filter($ids, fn($x) => $x > 0));
  if (empty($ids)) { $warn = '请选择需要删除的记录。'; }
  else { $deleted = delete_generation_logs($ids); $notice = '已删除 '.$deleted.' 条记录。'; }
}
$logs = list_generation_logs(100);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>AI 生成记录 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-6xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">AI 生成记录</h1>
        <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
      </div>
      <div class="card">
        <?php if ($notice): ?><div class="card-notice-ok"><?= htmlspecialchars($notice) ?></div><?php endif; ?>
        <?php if ($warn): ?><div class="card-notice-warn"><?= htmlspecialchars($warn) ?></div><?php endif; ?>
        <div class="mt-3 overflow-x-auto">
          <form method="post">
            <input type="hidden" name="action" value="bulk_delete" />
            <div class="mb-2 flex items-center gap-2">
              <button class="rounded-lg bg-red-600/80 hover:bg-red-600 px-3 py-1.5">删除选中</button>
              <label class="inline-flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" id="checkAll" class="scale-110" /> 全选</label>
            </div>
            <table class="w-full text-sm">
            <thead>
              <tr class="text-slate-400">
                <th class="text-left py-2 w-10"></th>
                <th class="text-left py-2">时间</th>
                <th class="text-left py-2">用户</th>
                <th class="text-left py-2">模型</th>
                <th class="text-left py-2">类型</th>
                <th class="text-left py-2">状态</th>
                <th class="text-left py-2">Tokens</th>
                <th class="text-left py-2">Prompt</th>
                <th class="text-left py-2">预览</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($logs as $r): ?>
                <tr class="border-t border-slate-800 align-top">
                  <td class="py-2"><input type="checkbox" name="ids[]" value="<?= (int)$r['id'] ?>" class="row-check scale-110" /></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars($r['created_at']) ?></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars($r['user_name'] ?? '-') ?></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars(($r['model_name'] ?? '-') . ' / ' . ($r['model_label'] ?? '-')) ?></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars($r['type']) ?></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars($r['status']) ?></td>
                  <td class="py-2 whitespace-nowrap"><?= htmlspecialchars((string)($r['tokens_used'] ?? '')) ?></td>
                  <td class="py-2"><pre class="whitespace-pre-wrap break-words max-w-[32rem] text-slate-300"><?= htmlspecialchars(mb_strimwidth($r['prompt'], 0, 600, '…', 'UTF-8')) ?></pre></td>
                  <td class="py-2"><pre class="whitespace-pre-wrap break-words max-w-[32rem] text-slate-300"><?= htmlspecialchars(mb_strimwidth((string)($r['preview'] ?? ''), 0, 600, '…', 'UTF-8')) ?></pre></td>
                </tr>
              <?php endforeach; if (empty($logs)): ?>
                <tr><td colspan="9" class="py-3 text-slate-400">暂无生成记录。</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
          </form>
        </div>
      </div>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; } .card-notice-ok{background-color:rgba(16,185,129,.12); border:1px solid rgba(16,185,129,.3); color:#34d399; border-radius:.75rem; padding:.5rem .75rem;} .card-notice-warn{background-color:rgba(234,179,8,.12); border:1px solid rgba(234,179,8,.3); color:#f59e0b; border-radius:.75rem; padding:.5rem .75rem;}</style>
    <script>
      const all = document.getElementById('checkAll');
      if (all) {
        all.addEventListener('change', () => {
          document.querySelectorAll('.row-check').forEach(cb => { cb.checked = all.checked; });
        });
      }
    </script>
  </body>
</html>