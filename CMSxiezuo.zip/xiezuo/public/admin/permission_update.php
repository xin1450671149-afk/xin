<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_permissions');

$id = (int)($_GET['id'] ?? 0);
$perm = $id ? get_permission($id) : null;
if (!$perm) {
    header('Location: /admin/permissions.php?msg=' . urlencode('权限不存在'));
    exit;
}

$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
update_permission($id, $name !== '' ? $name : $perm['name'], $description !== '' ? $description : null);

header('Location: /admin/permissions.php?msg=' . urlencode('权限更新成功'));
exit;
?>