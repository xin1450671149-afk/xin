<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$msg = null;
if (isset($_GET['action'])) {
  $action = $_GET['action'];
  if ($action === 'clear') {
    // 示例：清空缓存（实际项目可接入缓存系统）
    $msg = '缓存已清空（示例）';
  } elseif ($action === 'rebuild') {
    $msg = '缓存索引已重建（示例）';
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>缓存管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">缓存管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">缓存操作</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($msg): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card space-y-3">
            <div class="flex items-center gap-3">
              <a href="/admin/system_cache.php?action=clear" class="rounded-lg bg-amber-600 px-4 py-2.5">清空缓存</a>
              <a href="/admin/system_cache.php?action=rebuild" class="rounded-lg bg-cyan-600 px-4 py-2.5">重建索引</a>
            </div>
            <p class="text-sm text-slate-300">以上操作为演示，未接入真实缓存系统。</p>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">状态</h3>
            <ul class="mt-2 space-y-2 text-sm text-slate-300">
              <li>缓存命中率：72%（示例）</li>
              <li>缓存键数量：1,024（示例）</li>
            </ul>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>