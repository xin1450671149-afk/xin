<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_roles');

$id = (int)($_GET['id'] ?? 0);
$role = $id ? get_role($id) : null;
if (!$role) {
    header('Location: /admin/roles.php?msg=' . urlencode('角色不存在'));
    exit;
}
$allPerms = list_permissions_all();
$assigned = get_role_permission_ids($id);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>编辑角色 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-4xl mx-auto p-6">
      <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">编辑角色：<?= htmlspecialchars($role['name']) ?></h1>
        <a href="/admin/roles.php" class="rounded-lg bg-slate-800 px-3 py-2">返回列表</a>
      </div>

      <form method="post" action="/admin/role_update.php?id=<?= (int)$role['id'] ?>" class="card space-y-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm">名称</label>
            <input type="text" name="name" value="<?= htmlspecialchars($role['name']) ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
          </div>
          <div>
            <label class="block text-sm">描述</label>
            <input type="text" name="description" value="<?= htmlspecialchars($role['description'] ?? '') ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
          </div>
        </div>

        <div>
          <h3 class="text-lg font-semibold mb-2">权限分配</h3>
          <div class="rounded-lg bg-slate-800/60 border border-slate-700 p-4 grid grid-cols-1 md:grid-cols-2 gap-2">
            <?php foreach ($allPerms as $p): $pid=(int)$p['id']; ?>
              <label class="inline-flex items-start gap-2 text-sm">
                <input type="checkbox" name="perm_ids[]" value="<?= $pid ?>" class="mt-0.5 rounded" <?= in_array($pid, $assigned, true) ? 'checked' : '' ?> />
                <span>
                  <span class="font-medium text-slate-200"><?= htmlspecialchars($p['name']) ?></span>
                  <?php if (!empty($p['description'])): ?>
                    <span class="ml-2 text-slate-400"><?= htmlspecialchars($p['description']) ?></span>
                  <?php endif; ?>
                </span>
              </label>
            <?php endforeach; ?>
            <?php if (empty($allPerms)): ?>
              <p class="text-slate-400">暂无可分配权限</p>
            <?php endif; ?>
          </div>
        </div>

        <div class="flex items-center justify-between">
          <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
          <a href="/admin/role_delete.php?id=<?= (int)$role['id'] ?>" class="text-rose-400" onclick="return confirm('删除该角色？');">删除角色</a>
        </div>
      </form>
    </div>
  </body>
</html>