<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$id = (int)($_GET['id'] ?? 0);
$tag = $id ? get_tag($id) : null;
if (!$tag) { header('Location: /admin/tags.php'); exit; }
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>编辑标签 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-3xl mx-auto p-6">
      <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-semibold">编辑标签</h1>
        <a href="/admin/tags.php" class="rounded-lg bg-slate-800 px-3 py-2">返回列表</a>
      </div>

      <form action="/admin/tag_update.php" method="post" class="card space-y-3">
        <input type="hidden" name="id" value="<?= (int)$tag['id'] ?>" />
        <div>
          <label class="block text-sm">名称</label>
          <input name="name" value="<?= htmlspecialchars($tag['name']) ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
        </div>
        <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
      </form>
    </div>
    <style>
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
  </body>
</html>