<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_roles');

$id = (int)($_GET['id'] ?? 0);
$role = $id ? get_role($id) : null;
if (!$role) {
    header('Location: /admin/roles.php?msg=' . urlencode('角色不存在'));
    exit;
}

$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
update_role($id, $name !== '' ? $name : $role['name'], $description !== '' ? $description : null);

$permIds = array_map('intval', $_POST['perm_ids'] ?? []);
set_role_permissions($id, $permIds);

// 如果当前登录用户修改了自身权限的角色，刷新权限缓存
start_session();
if (!empty($_SESSION['user_id'])) {
    // 简单策略：每次更新角色后刷新当前用户权限缓存
    $_SESSION['permissions'] = load_user_permissions((int)$_SESSION['user_id']);
}

header('Location: /admin/roles.php?msg=' . urlencode('角色更新成功'));
exit;
?>