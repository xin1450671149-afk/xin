<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$configPath = __DIR__ . '/../../server/config_site.php';
$cfg = file_exists($configPath) ? include $configPath : [
  'site_name' => '我的网站',
  'seo_title' => '',
  'seo_keywords' => '',
  'seo_description' => '',
  'company_name' => '',
  'icp_number' => '',
  'customer_service' => ''
];
$ok = false; $error = null; $msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $site_name = trim($_POST['site_name'] ?? '');
  $seo_title = trim($_POST['seo_title'] ?? '');
  $seo_keywords = trim($_POST['seo_keywords'] ?? '');
  $seo_description = trim($_POST['seo_description'] ?? '');
  $company_name = trim($_POST['company_name'] ?? '');
  $icp_number = trim($_POST['icp_number'] ?? '');
  $customer_service = trim($_POST['customer_service'] ?? '');

  if ($site_name === '') { $error = '请填写网站名称。'; }
  else {
    $newCfg = compact('site_name','seo_title','seo_keywords','seo_description','company_name','icp_number','customer_service');
    $content = "<?php\n// 网站配置：由网站配置页面自动生成\nreturn " . var_export($newCfg, true) . ";\n";
    $writable = is_writable($configPath) || is_writable(dirname($configPath));
    if (!$writable) { $error = '配置文件不可写：server/config_site.php'; }
    else {
      $bytes = @file_put_contents($configPath, $content);
      if ($bytes === false) { $error = '写入失败，请检查权限与磁盘空间。'; }
      else { $ok = true; $msg = '网站配置已保存。'; $cfg = $newCfg; }
    }
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>网站配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">网站配置</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">基础信息与 SEO</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <form method="post" class="space-y-4">
              <div>
                <label class="block text-sm">网站名称</label>
                <input name="site_name" value="<?php echo htmlspecialchars($cfg['site_name'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm">SEO 标题</label>
                  <input name="seo_title" value="<?php echo htmlspecialchars($cfg['seo_title'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">SEO 关键词</label>
                  <input name="seo_keywords" value="<?php echo htmlspecialchars($cfg['seo_keywords'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
              </div>
              <div>
                <label class="block text-sm">SEO 描述</label>
                <textarea name="seo_description" rows="3" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><?php echo htmlspecialchars($cfg['seo_description'] ?? ''); ?></textarea>
              </div>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm">公司名称</label>
                  <input name="company_name" value="<?php echo htmlspecialchars($cfg['company_name'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">备案号</label>
                  <input name="icp_number" value="<?php echo htmlspecialchars($cfg['icp_number'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
              </div>
              <div>
                <label class="block text-sm">客服信息</label>
                <textarea name="customer_service" rows="3" placeholder="例如：电话、邮箱、微信/QQ 等联系方式" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"><?php echo htmlspecialchars($cfg['customer_service'] ?? ''); ?></textarea>
              </div>
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
            </form>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">说明</h3>
            <p class="mt-2 text-sm text-slate-300">此页面仅维护站点与 SEO 字段，写入 <code>server/config_site.php</code>。原“配置管理”页保留为数据库配置。</p>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>