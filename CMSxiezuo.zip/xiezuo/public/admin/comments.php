<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');
$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$total = comments_count($q ?: null, $status ?: null);
$comments = list_comments($page, $perPage, $q ?: null, $status ?: null);
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>评论管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">评论管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
          <a class="nav-item" href="/admin/articles.php">文章管理</a>
          <a class="nav-item" href="/admin/categories.php">分类管理</a>
          <a class="nav-item" href="/admin/tags.php">标签管理</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">评论列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <form class="xl:col-span-3 mb-2 grid grid-cols-1 md:grid-cols-3 gap-2 items-center" method="get" action="/admin/comments.php" aria-label="筛选评论">
            <input type="search" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="搜索作者或内容..." class="rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
            <select name="status" class="rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
              <option value="">全部状态</option>
              <option value="pending" <?= $status==='pending'?'selected':'' ?>>待审核</option>
              <option value="approved" <?= $status==='approved'?'selected':'' ?>>已通过</option>
              <option value="spam" <?= $status==='spam'?'selected':'' ?>>垃圾</option>
            </select>
            <button class="rounded-lg bg-slate-800 px-3 py-2">筛选</button>
          </form>

          <section class="xl:col-span-3 card">
            <form method="post" action="/admin/comment_update_status.php" id="bulkForm">
              <div class="flex items-center justify-between mb-3">
                <div class="text-sm text-slate-400">共 <?= (int)$total ?> 条</div>
                <div class="flex items-center gap-2">
                  <input type="hidden" name="status" id="bulkStatus" />
                  <button type="button" class="rounded bg-emerald-600/80 px-3 py-1.5" onclick="submitBulk('approved')">批量通过</button>
                  <button type="button" class="rounded bg-amber-600/80 px-3 py-1.5" onclick="submitBulk('pending')">批量待审</button>
                  <button type="button" class="rounded bg-rose-600/80 px-3 py-1.5" onclick="submitBulk('spam')">批量垃圾</button>
                </div>
              </div>
              <table class="w-full text-sm">
                <thead>
                  <tr class="text-slate-400">
                    <th class="p-2"><input type="checkbox" onclick="toggleAll(this)" /></th>
                    <th class="text-left p-2">作者</th>
                    <th class="text-left p-2">内容</th>
                    <th class="text-left p-2">文章</th>
                    <th class="text-left p-2">状态</th>
                    <th class="text-left p-2">创建时间</th>
                    <th class="text-left p-2">操作</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($comments as $c): ?>
                  <tr class="border-t border-slate-800">
                    <td class="p-2 align-top"><input type="checkbox" name="ids[]" value="<?= (int)$c['id'] ?>" /></td>
                    <td class="p-2 align-top whitespace-nowrap"><?= htmlspecialchars($c['author']) ?></td>
                    <td class="p-2 align-top text-slate-300 line-clamp-3"><?= htmlspecialchars($c['body']) ?></td>
                    <td class="p-2 align-top"><span class="text-slate-400"><?= htmlspecialchars($c['article_title']) ?></span></td>
                    <td class="p-2 align-top">
                      <?php if ($c['status']==='approved'): ?><span class="rounded bg-emerald-500/20 text-emerald-400 px-2 py-0.5 text-xs">已通过</span><?php endif; ?>
                      <?php if ($c['status']==='pending'): ?><span class="rounded bg-amber-500/20 text-amber-400 px-2 py-0.5 text-xs">待审核</span><?php endif; ?>
                      <?php if ($c['status']==='spam'): ?><span class="rounded bg-rose-500/20 text-rose-400 px-2 py-0.5 text-xs">垃圾</span><?php endif; ?>
                    </td>
                    <td class="p-2 align-top whitespace-nowrap"><?= htmlspecialchars($c['created_at']) ?></td>
                    <td class="p-2 align-top">
                      <a href="/admin/comment_detail.php?id=<?= (int)$c['id'] ?>" class="text-cyan-400">详情</a>
                      <span class="mx-2 text-slate-600">|</span>
                      <form class="inline" method="post" action="/admin/comment_update_status.php">
                        <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
                        <input type="hidden" name="status" value="approved" />
                        <button class="text-emerald-400">通过</button>
                      </form>
                      <span class="mx-2 text-slate-600">|</span>
                      <form class="inline" method="post" action="/admin/comment_update_status.php">
                        <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
                        <input type="hidden" name="status" value="pending" />
                        <button class="text-amber-400">待审</button>
                      </form>
                      <span class="mx-2 text-slate-600">|</span>
                      <form class="inline" method="post" action="/admin/comment_update_status.php" onsubmit="return confirm('确认标记为垃圾？');">
                        <input type="hidden" name="ids[]" value="<?= (int)$c['id'] ?>" />
                        <input type="hidden" name="status" value="spam" />
                        <button class="text-rose-400">垃圾</button>
                      </form>
                      <span class="mx-2 text-slate-600">|</span>
                      <a href="/admin/comment_delete.php?id=<?= (int)$c['id'] ?>" class="text-rose-400" onclick="return confirm('确认删除该评论？');">删除</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php if (empty($comments)): ?>
                  <tr><td class="p-3 text-slate-400" colspan="7">暂无评论</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </form>
            <?php $pages = max(1, (int)ceil($total / $perPage)); if ($pages > 1): ?>
              <nav class="mt-4 flex items-center gap-2" aria-label="分页导航">
                <?php for ($i = 1; $i <= $pages; $i++): $active = $i === $page; ?>
                  <a class="rounded-md border border-slate-700 px-3 py-1 <?= $active ? 'bg-slate-800 text-white' : 'text-slate-300' ?>" href="/admin/comments.php?page=<?= $i ?>&q=<?= urlencode($q) ?>&status=<?= urlencode($status) ?>">
                    <?= $i ?>
                  </a>
                <?php endfor; ?>
              </nav>
            <?php endif; ?>
          </section>
        </div>
      </main>
    </div>
    <style>
      .nav-item { display:block; margin-top:0.25rem; padding:0.5rem 0.75rem; border-radius:0.5rem; color:#cbd5e1; }
      .nav-item:hover { background-color: rgba(30,41,59,0.7); color:#fff; }
      .card { border-radius:1rem; background-color:rgba(2,6,23,0.7); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; }
    </style>
    <script>
      function toggleAll(box){
        document.querySelectorAll('input[name="ids[]"]').forEach(cb=>cb.checked = box.checked);
      }
      function submitBulk(status){
        document.getElementById('bulkStatus').value = status;
        const any = Array.from(document.querySelectorAll('input[name="ids[]"]')).some(cb=>cb.checked);
        if(!any){ alert('请先勾选评论'); return; }
        document.getElementById('bulkForm').submit();
      }
    </script>
  </body>
</html>