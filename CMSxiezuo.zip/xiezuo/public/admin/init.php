<?php
// Web 初始化入口：用于宝塔等环境无法便捷运行 CLI 时触发数据库初始化与迁移
// 安全说明：需在 server/config.php 中设置 'init_token'，访问时携带 ?token=... 才会执行

$cfg = include __DIR__ . '/../../server/config.php';
$setToken = (string)($cfg['init_token'] ?? '');
$reqToken = (string)($_GET['token'] ?? '');

if ($setToken === '' || $reqToken !== $setToken) {
  http_response_code(403);
  echo 'Forbidden: invalid or empty init token';
  exit;
}

// 执行 CLI 初始化脚本（包含：自动创建数据库、建表、迁移、默认管理员与权限角色）
require __DIR__ . '/../../server/seed.php';
?>