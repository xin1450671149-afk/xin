<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$configPath = __DIR__ . '/../../server/config_email.php';
$cfg = file_exists($configPath) ? include $configPath : [
  'smtp_host' => '', 'smtp_port' => 465, 'secure' => 'ssl',
  'smtp_user' => '', 'smtp_pass' => '',
  'from_email' => '', 'from_name' => 'CMS'
];
$ok = false; $error = null; $msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $smtp_host = trim($_POST['smtp_host'] ?? '');
  $smtp_port = (int)($_POST['smtp_port'] ?? 465);
  $secure = trim($_POST['secure'] ?? 'ssl');
  $smtp_user = trim($_POST['smtp_user'] ?? '');
  $smtp_pass = trim($_POST['smtp_pass'] ?? '');
  $from_email = trim($_POST['from_email'] ?? '');
  $from_name = trim($_POST['from_name'] ?? 'CMS');

  if ($smtp_host === '' || $smtp_port <= 0 || $smtp_user === '' || $from_email === '') {
    $error = '请填写完整的 SMTP 主机、端口、账号与发件邮箱。';
  } else {
    $newCfg = compact('smtp_host','smtp_port','secure','smtp_user','smtp_pass','from_email','from_name');
    $content = "<?php\n// 邮箱配置：由系统邮箱配置页面自动生成\nreturn " . var_export($newCfg, true) . ";\n";
    $writable = is_writable($configPath) || is_writable(dirname($configPath));
    if (!$writable) { $error = '配置文件不可写：server/config_email.php'; }
    else {
      $bytes = @file_put_contents($configPath, $content);
      if ($bytes === false) { $error = '写入失败，请检查权限与磁盘空间。'; }
      else { $ok = true; $msg = '邮箱配置已保存。'; $cfg = $newCfg; }
    }
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>邮箱配置 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">邮箱配置</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">SMTP 设置</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <form method="post" class="space-y-3">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm">SMTP 主机</label>
                  <input name="smtp_host" value="<?php echo htmlspecialchars($cfg['smtp_host'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">端口</label>
                  <input name="smtp_port" type="number" value="<?php echo (int)($cfg['smtp_port'] ?? 465); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">加密方式</label>
                  <select name="secure" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                    <option value="ssl" <?php echo (($cfg['secure'] ?? '')==='ssl')?'selected':''; ?>>SSL</option>
                    <option value="tls" <?php echo (($cfg['secure'] ?? '')==='tls')?'selected':''; ?>>TLS</option>
                    <option value="none" <?php echo (($cfg['secure'] ?? '')==='none')?'selected':''; ?>>无</option>
                  </select>
                </div>
                <div>
                  <label class="block text-sm">账号</label>
                  <input name="smtp_user" value="<?php echo htmlspecialchars($cfg['smtp_user'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">密码/授权码</label>
                  <input name="smtp_pass" type="password" value="<?php echo htmlspecialchars($cfg['smtp_pass'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">发件邮箱</label>
                  <input name="from_email" value="<?php echo htmlspecialchars($cfg['from_email'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">发件人名称</label>
                  <input name="from_name" value="<?php echo htmlspecialchars($cfg['from_name'] ?? 'CMS'); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
              </div>
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
            </form>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">说明</h3>
            <p class="mt-2 text-sm text-slate-300">此页面写入 <code>server/config_email.php</code>。实际项目可在此基础上接入发送测试等功能。</p>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>