<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$ids = array_map('intval', $_POST['ids'] ?? []);
$status = $_POST['status'] ?? '';
$allowed = ['pending','approved','spam'];
if (empty($ids) || !in_array($status, $allowed, true)) {
  header('Location: /admin/comments.php?error=bad_request');
  exit;
}

bulk_update_comments_status($ids, $status);
header('Location: /admin/comments.php?ok=1');
exit;