<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$name = trim($_POST['name'] ?? '');
if ($name === '') { header('Location: /admin/tags.php?error=name'); exit; }

create_tag($name);
header('Location: /admin/tags.php?ok=1');
exit;