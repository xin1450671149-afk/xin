<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/content.php';
require_login();
require_permission('manage_content');

$id = (int)($_POST['id'] ?? 0);
$name = trim($_POST['name'] ?? '');
if (!$id || $name === '') { header('Location: /admin/tags.php?error=update'); exit; }

update_tag($id, $name);
header('Location: /admin/tags.php?ok=1');
exit;