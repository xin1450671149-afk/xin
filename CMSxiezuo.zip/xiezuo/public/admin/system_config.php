<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_system');

$configPath = __DIR__ . '/../../server/config.php';
$cfg = include $configPath;
$ok = false;
$msg = null;
$error = null;

function sanitize_dbname(string $name): string {
  $n = trim($name);
  return $n === '' ? '' : preg_replace('/[^a-zA-Z0-9_]/', '', $n);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $host = trim($_POST['host'] ?? '');
  $port = (int)($_POST['port'] ?? 3306);
  $dbname = sanitize_dbname($_POST['dbname'] ?? '');
  $user = trim($_POST['user'] ?? '');
  $pass = trim($_POST['pass'] ?? '');
  $charset = trim($_POST['charset'] ?? 'utf8mb4');

  if ($host === '' || $port <= 0 || $dbname === '' || $user === '' || $charset === '') {
    $error = '请输入有效的数据库配置（主机、端口、库名、用户名、字符集）。';
  } else {
    $newCfg = [
      'host' => $host,
      'port' => $port,
      'dbname' => $dbname,
      'user' => $user,
      'pass' => $pass,
      'charset' => $charset,
    ];

    $content = "<?php\n// 数据库配置：由系统配置页面自动生成\nreturn " . var_export($newCfg, true) . ";\n";
    $writable = is_writable($configPath) || is_writable(dirname($configPath));
    if (!$writable) {
      $error = '配置文件不可写，请检查文件或目录权限：server/config.php';
    } else {
      $bytes = @file_put_contents($configPath, $content);
      if ($bytes === false) {
        $error = '写入失败，请检查权限与磁盘空间。';
      } else {
        $ok = true;
        $msg = '数据库配置已保存。';
        $cfg = $newCfg; // 刷新当前显示值
      }
    }
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>配置管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">配置管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">系统配置</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($ok): ?><div class="xl:col-span-3 card-notice-ok"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
          <?php if ($error): ?><div class="xl:col-span-3 card-notice-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <h3 class="text-lg font-semibold">数据库配置</h3>
            <form method="post" class="mt-4 space-y-3">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label class="block text-sm">主机</label>
                  <input name="host" value="<?php echo htmlspecialchars($cfg['host'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">端口</label>
                  <input name="port" type="number" value="<?php echo (int)($cfg['port'] ?? 3306); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">数据库名</label>
                  <input name="dbname" value="<?php echo htmlspecialchars($cfg['dbname'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">字符集</label>
                  <input name="charset" value="<?php echo htmlspecialchars($cfg['charset'] ?? 'utf8mb4'); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">用户名</label>
                  <input name="user" value="<?php echo htmlspecialchars($cfg['user'] ?? ''); ?>" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
                <div>
                  <label class="block text-sm">密码</label>
                  <input name="pass" type="password" value="<?php echo htmlspecialchars($cfg['pass'] ?? ''); ?>" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
                </div>
              </div>
              <button type="submit" class="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">保存</button>
            </form>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">说明</h3>
            <p class="mt-2 text-sm text-slate-300">此页面直接写入 <code>server/config.php</code>。若保存失败，请检查文件或目录写权限。</p>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>