<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_users');

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$email = trim($_POST['email'] ?? '');

if (empty($username) || empty($password)) {
    header('Location: /admin/users.php?error=empty');
    exit;
}

try {
    create_user($username, $password, $email ?: null);
    header('Location: /admin/users.php?ok=1');
} catch (Throwable $e) {
    header('Location: /admin/users.php?error=' . urlencode($e->getMessage()));
}
exit;