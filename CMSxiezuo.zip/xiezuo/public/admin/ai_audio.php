<?php
require_once __DIR__ . '/../../server/auth.php';
require_once __DIR__ . '/../../server/ai.php';
require_login();
require_permission('manage_system');

$models = list_ai_models();
$error = null; $result = null; $preview = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $prompt = trim($_POST['prompt'] ?? '');
  $voice = trim($_POST['voice'] ?? 'female');
  $model_id = (int)($_POST['model_id'] ?? 0);
  if ($prompt === '' || $model_id === 0) {
    $error = '请填写文本并选择模型';
  } else {
    $gen = generate_audio_tts($model_id, $prompt, $voice, 'mp3');
    start_session();
    $user_id = !empty($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    if (!empty($gen['ok'])) {
      $preview = $gen['preview'] ?? null;
      log_generation($user_id, $model_id, 'audio', $prompt, $preview, null, 'success');
      $result = '语音生成成功，下面为预览（可下载）。';
    } else {
      $error = '生成失败：' . htmlspecialchars((string)($gen['error'] ?? 'unknown'));
      if (!empty($gen['url'])) { $error .= ' · URL: ' . htmlspecialchars($gen['url']); }
      log_generation($user_id, $model_id, 'audio', $prompt, null, null, 'failed');
    }
  }
}
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>语音生成 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="max-w-5xl mx-auto p-6 space-y-6">
      <div class="flex items-center justify-between">
        <h1 class="text-xl font-semibold">语音生成</h1>
        <div class="flex items-center gap-2">
          <a href="/dashboard.php" class="rounded-lg bg-slate-800 px-3 py-2">返回仪表盘</a>
          <a href="/admin/ai_logs.php" class="rounded-lg bg-slate-800 px-3 py-2">生成记录</a>
        </div>
      </div>

      <div class="card">
        <?php if (empty($models)): ?>
          <div class="card-notice-warn">尚未配置模型，请先在“AI 模型配置”中添加。</div>
          <a class="inline-block mt-3 text-cyan-400" href="/admin/ai_models.php">前往模型配置</a>
        <?php else: ?>
          <?php if ($error): ?><div class="card-notice-warn"><?= htmlspecialchars($error) ?></div><?php endif; ?>
          <?php if ($result): ?><div class="card-notice-ok"><?= htmlspecialchars($result) ?></div><?php endif; ?>
          <form method="post" class="space-y-3">
            <div>
              <label class="block text-sm mb-1">选择模型</label>
              <select name="model_id" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                <?php foreach ($models as $m): ?>
                  <option value="<?= (int)$m['id'] ?>"><?= htmlspecialchars($m['name'].' · '.$m['model']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label class="block text-sm mb-1">文本</label>
                <textarea name="prompt" rows="4" placeholder="请输入需要合成的文本" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2"></textarea>
              </div>
              <div>
                <label class="block text-sm mb-1">发音人</label>
                <select name="voice" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2">
                  <option value="female">女声</option>
                  <option value="male">男声</option>
                  <option value="child">童声</option>
                </select>
              </div>
            </div>
            <div>
              <button class="rounded-lg bg-slate-800 px-4 py-2">提交生成</button>
            </div>
          </form>
        <?php endif; ?>
      </div>

      <?php if ($preview): ?>
      <div class="card">
        <h2 class="text-lg font-semibold">语音预览</h2>
        <audio class="mt-3 w-full" controls src="<?= htmlspecialchars($preview) ?>"></audio>
      </div>
      <?php endif; ?>
    </div>
    <style>.card { border-radius:1rem; background-color:rgba(2,6,23,0.7); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.06); padding:1rem; } .card-notice-ok{background-color:rgba(16,185,129,.12); border:1px solid rgba(16,185,129,.3); color:#34d399; border-radius:.75rem; padding:.5rem .75rem;} .card-notice-warn{background-color:rgba(234,179,8,.12); border:1px solid rgba(234,179,8,.3); color:#f59e0b; border-radius:.75rem; padding:.5rem .75rem;}</style>
  </body>
</html>