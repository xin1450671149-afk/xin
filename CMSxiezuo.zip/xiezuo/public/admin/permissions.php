<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_permissions');
$perms = list_permissions_all();
$msg = $_GET['msg'] ?? null;
?>
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>权限管理 · CMS 管理后台</title>
    <link href="/assets/vendor/tailwind.min.css" rel="stylesheet">
    <link href="/assets/vendor/inter.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/styles.css" />
  </head>
  <body class="min-h-screen bg-slate-900 text-slate-100 font-[Inter]">
    <div class="flex min-h-screen">
      <aside class="w-64 border-r border-slate-800 bg-slate-900/80 backdrop-blur">
        <div class="h-16 flex items-center px-4 border-b border-slate-800">
          <span class="text-lg font-semibold">权限管理</span>
        </div>
        <nav class="px-3 py-3 space-y-2">
          <a class="nav-item" href="/dashboard.php">返回仪表盘</a>
        </nav>
      </aside>

      <main class="flex-1">
        <div class="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-900/60 backdrop-blur">
          <h2 class="text-lg font-semibold">权限列表</h2>
          <a href="/logout.php" class="rounded-lg bg-slate-800 px-3 py-2">退出</a>
        </div>

        <div class="p-6 grid grid-cols-1 xl:grid-cols-3 gap-6">
          <?php if ($msg): ?><div class="xl:col-span-3 card-notice-ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

          <section class="xl:col-span-2 card">
            <table class="w-full text-sm">
              <thead>
                <tr class="text-slate-400">
                  <th class="text-left p-2">ID</th>
                  <th class="text-left p-2">名称</th>
                  <th class="text-left p-2">描述</th>
                  <th class="text-left p-2">操作</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($perms as $p): ?>
                <tr class="border-t border-slate-800">
                  <td class="p-2"><?= (int)$p['id'] ?></td>
                  <td class="p-2"><?= htmlspecialchars($p['name']) ?></td>
                  <td class="p-2"><?= htmlspecialchars($p['description'] ?? '') ?></td>
                  <td class="p-2">
                    <a href="/admin/permission_edit.php?id=<?= (int)$p['id'] ?>" class="text-cyan-400">编辑</a>
                    <span class="mx-2 text-slate-600">|</span>
                    <a href="/admin/permission_delete.php?id=<?= (int)$p['id'] ?>" class="text-rose-400" onclick="return confirm('删除该权限？');">删除</a>
                  </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($perms)): ?>
                <tr><td class="p-3 text-slate-400" colspan="4">暂无权限</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </section>

          <section class="card">
            <h3 class="text-lg font-semibold">新增权限</h3>
            <form method="post" action="/admin/permission_create.php" class="mt-4 space-y-3">
              <div>
                <label class="block text-sm">名称</label>
                <input name="name" required class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <div>
                <label class="block text-sm">描述</label>
                <input name="description" class="w-full rounded-lg bg-slate-800/60 border border-slate-700 px-3 py-2" />
              </div>
              <button type="submit" class="w-full rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5">创建</button>
            </form>
          </section>
        </div>
      </main>
    </div>
  </body>
</html>