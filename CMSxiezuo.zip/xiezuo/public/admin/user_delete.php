<?php
require_once __DIR__ . '/../../server/auth.php';
require_login();
require_permission('manage_users');

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: /admin/users.php?error=no_id');
    exit;
}

delete_user($id);
header('Location: /admin/users.php?ok=1');
exit;