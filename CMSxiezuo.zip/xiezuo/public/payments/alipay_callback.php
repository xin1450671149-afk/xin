<?php
require_once __DIR__ . '/../../server/pay.php';
require_once __DIR__ . '/../../server/recharge.php';
// 支付宝服务器通知回调（示例：仅记录，不进行签名校验）
$payload = file_get_contents('php://input');
if (!$payload) { $payload = http_build_query($_POST ?: []); }
$id = log_payment_notification('alipay', $payload, 'received');

// 解析参数并处理充值订单（仅示例，未做签名校验）
$params = $_POST;
if (empty($params) && !empty($payload)) {
  parse_str($payload, $params);
}
$out_trade_no = $params['out_trade_no'] ?? null;
$trade_status = $params['trade_status'] ?? null;
$trade_no = $params['trade_no'] ?? '';
if ($out_trade_no && $trade_status) {
  $order = get_recharge_by_out_trade_no($out_trade_no);
  if ($order) {
    if ($trade_status === 'TRADE_SUCCESS' || $trade_status === 'TRADE_FINISHED') {
      mark_recharge_paid($out_trade_no, $trade_no, (int)$id);
    } elseif ($trade_status === 'TRADE_CLOSED') {
      mark_recharge_failed($out_trade_no, (int)$id);
    }
  }
}

http_response_code(200);
echo 'success';
?>