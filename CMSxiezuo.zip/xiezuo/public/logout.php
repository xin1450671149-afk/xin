<?php
require_once __DIR__ . '/../server/auth.php';
logout();
header('Location: /login.html');
exit;