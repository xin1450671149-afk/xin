// Simple theme toggle and sidebar toggle for demo purposes
(function () {
  const root = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const loginError = document.getElementById('loginError');

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isDark = root.classList.toggle('light');
      // flip colors for light mode
      if (isDark) {
        document.body.classList.remove('bg-slate-900');
        document.body.classList.add('bg-slate-50');
      } else {
        document.body.classList.add('bg-slate-900');
        document.body.classList.remove('bg-slate-50');
      }
    });
  }

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
      if (window.innerWidth < 1024) {
        sidebar.classList.toggle('hidden');
      } else {
        sidebar.classList.toggle('w-72');
        sidebar.classList.toggle('w-16');
      }
    });
  }

  // Show login error from query string
  if (loginError && /login\.html$/.test(location.pathname)) {
    const params = new URLSearchParams(location.search);
    if (params.has('error')) {
      loginError.classList.remove('hidden');
    }
  }
})();